// KANEKI STORE — somente chaves públicas. Nunca coloque service role ou token do Mercado Pago aqui.
window.KANEKI_SUPABASE_URL = 'https://zcbikpvgrhjzpsuclnhg.supabase.co';
window.KANEKI_SUPABASE_ANON_KEY = 'sb_publishable_T4Y8cgkj0KiiNz_dMTdQiA_RxqpAcwE';
