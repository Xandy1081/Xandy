
/* ===== V12.10 - PAINEIS BONITOS + CANAL DE ENTREGAS ===== */
function kanekiNotice(message,opts={}){
  let root=document.getElementById('kanekiNoticeOverlay');
  if(!root){
    root=document.createElement('div');
    root.id='kanekiNoticeOverlay';
    root.className='kaneki-notice-overlay hidden';
    root.innerHTML=`<div class="kaneki-notice-card">
      <button class="kaneki-notice-x" onclick="closeKanekiNotice()">✕</button>
      <div id="kanekiNoticeIcon" class="kaneki-notice-icon">!</div>
      <div class="kaneki-notice-body">
        <small id="kanekiNoticeEyebrow">KANEKI STORE</small>
        <h3 id="kanekiNoticeTitle">Aviso</h3>
        <p id="kanekiNoticeMessage"></p>
      </div>
      <button class="btn kaneki-notice-ok" onclick="closeKanekiNotice()">OK</button>
    </div>`;
    document.body.appendChild(root);
  }
  const text=String(message??'');
  const type=opts.type||(text.includes('✅')?'success':text.toLowerCase().includes('erro')||text.toLowerCase().includes('não foi possível')?'error':'info');
  root.dataset.type=type;
  const title=opts.title||(type==='success'?'Tudo certo':type==='error'?'Não foi possível':'Atenção');
  const icon=opts.icon||(type==='success'?'✓':type==='error'?'!':'i');
  document.getElementById('kanekiNoticeTitle').textContent=title;
  document.getElementById('kanekiNoticeMessage').textContent=text.replace(/^✅\s*/,'');
  document.getElementById('kanekiNoticeIcon').textContent=icon;
  root.classList.remove('hidden');
}
function closeKanekiNotice(){document.getElementById('kanekiNoticeOverlay')?.classList.add('hidden')}
window.alert=(message)=>kanekiNotice(message);

let deliveriesChannel=null;
function deliveryEsc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function openDeliveries(){
  document.getElementById('deliveriesModal')?.classList.remove('hidden');
  document.body.style.overflow='hidden';
  loadDeliveries(true);
}
function closeDeliveries(){
  document.getElementById('deliveriesModal')?.classList.add('hidden');
  document.body.style.overflow='';
}
async function loadDeliveries(subscribe=false){
  const box=document.getElementById('deliveriesFeed');
  if(!box||!window.supabaseClient)return;
  const {data,error}=await supabaseClient.from('deliveries').select('*').eq('active',true).order('created_at',{ascending:false}).limit(300);
  if(error){
    box.innerHTML='<div class="delivery-empty">As entregas publicadas aparecerão aqui.</div>';
    return;
  }
  const rows=data||[];
  box.innerHTML=rows.length?rows.map(d=>`<article class="delivery-post">
    <div class="delivery-post-profile">
      <img class="delivery-post-avatar" src="${deliveryEsc(document.querySelector('.js-store-avatar')?.src||'/assets/logo.svg')}" alt="KANEKI STORE">
      <div><b>KANEKI STORE</b><small>Entrega oficial verificada</small></div>
      <span class="delivery-verified">✓</span>
    </div>
    ${d.image_url?`<img class="delivery-post-image" src="${deliveryEsc(d.image_url)}" alt="Comprovante visual da entrega">`:''}
    <div class="delivery-post-content">
      <span class="delivery-post-status">✅ PEDIDO ENTREGUE</span>
      <h3>${deliveryEsc(d.customer_name||'Cliente')}</h3>
      <p class="delivery-items">${deliveryEsc(d.items_text||'Pedido entregue com sucesso.')}</p>
      ${d.message?`<p>${deliveryEsc(d.message)}</p>`:''}
      <small>${new Date(d.created_at).toLocaleString('pt-BR')}</small>
    </div>
  </article>`).join(''):'<div class="delivery-empty"><b>📦 Nenhuma entrega publicada ainda.</b><span>Quando a KANEKI STORE publicar uma entrega, ela aparecerá aqui.</span></div>';
  if(subscribe&&!deliveriesChannel){
    deliveriesChannel=supabaseClient.channel('public-deliveries').on('postgres_changes',{event:'*',schema:'public',table:'deliveries'},()=>loadDeliveries(false)).subscribe();
  }
}

const DEFAULT_PRODUCTS=[];
let products=[], cart=JSON.parse(localStorage.getItem('kaneki_cart')||'[]'), category='Todos', productDiscounts={};
const $=s=>document.querySelector(s), money=n=>Number(n).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const CART_TTL_MS=15*60*1000;let cartExpiryTimer=null;
function saveCart(){localStorage.setItem('kaneki_cart',JSON.stringify(cart));if(cart.length){if(!localStorage.getItem('kaneki_cart_expires_at'))localStorage.setItem('kaneki_cart_expires_at',String(Date.now()+CART_TTL_MS));scheduleCartExpiry()}else localStorage.removeItem('kaneki_cart_expires_at')}
function scheduleCartExpiry(){if(cartExpiryTimer)clearTimeout(cartExpiryTimer);const exp=Number(localStorage.getItem('kaneki_cart_expires_at')||0);if(!cart.length||!exp)return;const left=exp-Date.now();if(left<=0){cart=[];localStorage.removeItem('kaneki_cart');localStorage.removeItem('kaneki_cart_expires_at');renderCart();return}cartExpiryTimer=setTimeout(()=>{cart=[];localStorage.removeItem('kaneki_cart');localStorage.removeItem('kaneki_cart_expires_at');renderCart();alert('Seu carrinho expirou após 15 minutos. Adicione os produtos novamente.');closeCart()},left)}
function resetCartExpiryIfNeeded(){if(cart.length&&!localStorage.getItem('kaneki_cart_expires_at'))localStorage.setItem('kaneki_cart_expires_at',String(Date.now()+CART_TTL_MS));scheduleCartExpiry()}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function normalizeCategory(v){return String(v??'').trim().replace(/\s+/g,' ').toLocaleLowerCase('pt-BR')}
function discountPercent(id){const v=Number(productDiscounts?.[String(id)]??productDiscounts?.[id]??0);return Math.max(0,Math.min(95,Number.isFinite(v)?v:0))}
function applyDiscountPrice(p){const d=discountPercent(p.id),base=Number(p.base_price??p.price)||0;return d>0?Number((base*(1-d/100)).toFixed(2)):base}
function render(){
 const q=($('#search')?.value||'').toLocaleLowerCase('pt-BR');
 const categoryMap=new Map();
 (publicCategories||[]).forEach(c=>{const label=String(c.name||'').trim().replace(/\s+/g,' '),key=normalizeCategory(label);if(key&&!categoryMap.has(key))categoryMap.set(key,label)});
 products.forEach(p=>{const label=String(p.category||'Produtos').trim().replace(/\s+/g,' '),key=normalizeCategory(label);if(key&&!categoryMap.has(key))categoryMap.set(key,label)});
 if(category!=='Todos'&&!categoryMap.has(normalizeCategory(category)))category='Todos';
 const cats=['Todos',...categoryMap.values()],categoriesEl=$('#categories');
 const catButtons=cats.map((c,i)=>`<button type="button" class="${normalizeCategory(c)===normalizeCategory(category)?'active':''}" data-category-index="${i}">${escapeHtml(c)}</button>`).join('');
 if(categoriesEl){
   categoriesEl.innerHTML=catButtons;
   categoriesEl.querySelectorAll('[data-category-index]').forEach(btn=>btn.addEventListener('click',()=>setCategory(cats[Number(btn.dataset.categoryIndex)])));
 }
 const topCats=$('#topCategoriesList');
 if(topCats){
   topCats.innerHTML=cats.map((c,i)=>`<button type="button" class="${normalizeCategory(c)===normalizeCategory(category)?'active':''}" data-top-category-index="${i}">${escapeHtml(c)}</button>`).join('');
   topCats.querySelectorAll('[data-top-category-index]').forEach(btn=>btn.addEventListener('click',()=>setCategory(cats[Number(btn.dataset.topCategoryIndex)])));
 }
 const ct=$('#categoryTitle');if(ct)ct.textContent=(category==='Todos'?'TODOS OS PRODUTOS':category).toUpperCase();
 const list=products.filter(p=>(category==='Todos'||normalizeCategory(p.category)===normalizeCategory(category))&&(String(p.name||'').toLocaleLowerCase('pt-BR').includes(q)||String(p.category||'').toLocaleLowerCase('pt-BR').includes(q)));
 $('#products').innerHTML=list.length?list.map(p=>{const st=Number(p.stock)||0,d=discountPercent(p.id),base=Number(p.base_price??p.price)||0,final=applyDiscountPrice(p);return `<article class="card product-card-modern ${st<=0?'sold-out':''}"><div class="pic">${p.image?`<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy">`:'IMAGEM DO PRODUTO'}</div><div class="info"><div class="tag">${escapeHtml(p.category.toUpperCase())}</div><div class="name">${escapeHtml(p.name)}</div><div class="desc">${escapeHtml(p.desc)}</div><div class="price-row"><div>${d>0?`<div class="old-price">${money(base)} <span class="discount-badge">↘ - ${d}%</span></div>`:''}<div class="price">${money(final)}</div><div class="pix-note">À vista no Pix</div></div><div class="pix-side"><img src="/assets/pix-blue.png" alt="Pix" loading="lazy"></div></div><div class="stock-info">${st>0?'Estoque: '+st:'SEM ESTOQUE'}</div><button class="add" ${st<=0?'disabled':''} onclick="add(${p.id})">${st>0?'COMPRAR AGORA':'ESGOTADO'}</button></div>${st<=0?'<div class="sold-out-overlay"><span>ESTOQUE ESGOTADO</span></div>':''}</article>`}).join(''):'<p class="empty">Nenhum produto disponível</p>';
}
function setCategory(c){category=c;render();document.getElementById('categoriesPanel')?.classList.add('hidden');requestAnimationFrame(()=>document.getElementById('products')?.scrollIntoView({behavior:'smooth',block:'start'}))}
function add(id){const p=products.find(x=>x.id===id),x=cart.find(x=>x.id===id);if(!p)return;const st=Number(p.stock)||0;if(st<=0){alert('Produto sem estoque.');return}if(x&&x.qty>=st){alert('Você já colocou todo o estoque disponível no carrinho.');return}if(x)x.qty++;else cart.push({...p,qty:1});saveCart();renderCart();openCart()}
function removeItem(id){cart=cart.filter(x=>x.id!==id);saveCart();renderCart()}
function changeCartQty(id,delta){const x=cart.find(i=>i.id===id);if(!x)return;const p=products.find(i=>i.id===id);const max=Math.max(1,Number(p?.stock ?? x.stock ?? 1));const next=Number(x.qty||1)+delta;if(next<1){removeItem(id);return}if(next>max){alert('Quantidade máxima disponível em estoque: '+max);return}x.qty=next;saveCart();renderCart()}
function renderCart(){$('#cartCount').textContent=cart.reduce((s,x)=>s+x.qty,0);$('#cartItems').innerHTML=cart.length?cart.map(x=>`<div class="cart-item"><div class="cart-product-info"><b>${escapeHtml(x.name)}</b><small>${x.qty} × ${money(x.price)}</small><div class="cart-qty"><button type="button" onclick="changeCartQty(${x.id},-1)" aria-label="Diminuir quantidade">−</button><span>${x.qty}</span><button type="button" onclick="changeCartQty(${x.id},1)" aria-label="Aumentar quantidade">+</button></div></div><button class="remove" onclick="removeItem(${x.id})">Remover</button></div>`).join(''):'<p class="empty">Seu carrinho está vazio.</p>';$('#cartTotal').textContent=money(cart.reduce((s,x)=>s+x.price*x.qty,0))}
function openCart(){$('#cart').classList.add('open');$('#shade').classList.add('show')}
function closeCart(){$('#cart').classList.remove('open');$('#shade').classList.remove('show')}
let publicCategories=[];
async function loadProducts(){
 if(!window.KANEKI_SUPABASE_URL||window.KANEKI_SUPABASE_URL.startsWith('COLE_AQUI')){products=DEFAULT_PRODUCTS;publicCategories=[];render();return}
 try{
   const [{data,error},{data:ds},{data:catsData}] = await Promise.all([
     window.supabaseClient.from('products').select('id,name,price,category,description,image,stock,reserved_stock').eq('active',true).order('id'),
     window.supabaseClient.from('site_settings').select('value').eq('key','product_discounts').maybeSingle(),
     window.supabaseClient.from('categories').select('id,name,sort_order,active').eq('active',true).order('sort_order').order('name')
   ]);
   if(error)throw error;
   try{productDiscounts=JSON.parse(ds?.value||'{}')||{}}catch{productDiscounts={}}
   publicCategories=(catsData||[]).filter(c=>String(c.name||'').trim());
   products=(data||[]).map(p=>({...p,base_price:Number(p.price)||0,price:Number((Number(p.price||0)*(1-discountPercent(p.id)/100)).toFixed(2)),stock:Math.max(0,(Number(p.stock)||0)-(Number(p.reserved_stock)||0)),desc:p.description}));
   render()
 }catch(e){console.error(e);products=[];publicCategories=[];render()}
}
$('#search').addEventListener('input',render);$('#cartOpen').onclick=openCart;$('#cartClose').onclick=closeCart;$('#shade').onclick=closeCart;$('#checkout').onclick=startCheckout;
const topSearchBtn=document.getElementById('topSearchBtn'),topSearchPanel=document.getElementById('topSearchPanel'),topSearch=document.getElementById('topSearch'),topSearchClose=document.getElementById('topSearchClose');
if(topSearchBtn)topSearchBtn.onclick=()=>{topSearchPanel?.classList.toggle('hidden');if(!topSearchPanel?.classList.contains('hidden'))setTimeout(()=>topSearch?.focus(),60)};
if(topSearchClose)topSearchClose.onclick=()=>topSearchPanel?.classList.add('hidden');
if(topSearch)topSearch.addEventListener('input',()=>{const v=topSearch.value;const q=document.getElementById('search');if(q)q.value=v;render();document.getElementById('produtos')?.scrollIntoView({behavior:'smooth',block:'start'})});
const categoryBack=document.getElementById('categoryBack');if(categoryBack)categoryBack.onclick=()=>document.getElementById('categoriesPanel')?.classList.toggle('hidden');
renderCart();resetCartExpiryIfNeeded();

// ===== KANEKI: conta do cliente / Google =====
let currentUser=null, authInitialized=false;
function accountNameFromUser(user){
 const m=user?.user_metadata||{};
 return m.full_name||m.name||user?.email?.split('@')[0]||'Cliente KANEKI';
}
function updateAccountUI(){
 const label=document.getElementById('accountLabel'), out=document.getElementById('accountLoggedOut'), inn=document.getElementById('accountLoggedIn');
 if(!label)return;
 if(currentUser){
   const name=accountNameFromUser(currentUser), email=currentUser.email||'';
   label.textContent='Minha conta';
   if(out)out.classList.add('hidden'); if(inn)inn.classList.remove('hidden');
   document.getElementById('accountName').textContent=name;
   const av=document.getElementById('accountAvatar');
   const photo=currentUser?.user_metadata?.avatar_url||currentUser?.user_metadata?.picture||'';
   if(av){if(photo){av.textContent='';av.style.backgroundImage=`url(${photo})`;av.classList.add('has-photo')}else{av.style.backgroundImage='';av.classList.remove('has-photo');av.textContent=name.charAt(0).toUpperCase();}}
 }else{
   label.textContent='Entrar com Google';
   if(out)out.classList.remove('hidden'); if(inn)inn.classList.add('hidden');
 }
}
async function initAuth(){
 if(!window.supabaseClient)return;
 const {data}=await supabaseClient.auth.getSession();
 currentUser=data?.session?.user||null; authInitialized=true; updateAccountUI();
 if(currentUser){
   if(localStorage.getItem('kaneki_admin_oauth')==='1'){
     localStorage.removeItem('kaneki_admin_oauth');
     window.location.replace('/admin.html');
     return;
   }
   loadMyOrders();
 }
 supabaseClient.auth.onAuthStateChange((_event,session)=>{
   currentUser=session?.user||null; updateAccountUI();
   if(!document.getElementById('deliveriesModal')?.classList.contains('hidden'))loadDeliveries(false);
   if(currentUser){
     if(localStorage.getItem('kaneki_admin_oauth')==='1'){
       localStorage.removeItem('kaneki_admin_oauth');
       window.location.replace('/admin.html');
       return;
     }
     loadMyOrders();
   } else if(document.getElementById('myOrders'))document.getElementById('myOrders').innerHTML='<p class="muted">Entre para ver seus pedidos.</p>';
 });
}
function openAccount(){updateAccountUI();document.getElementById('myOrdersSection')?.classList.add('hidden');document.getElementById('accountModal').classList.remove('hidden');if(currentUser)loadMyOrders(false)}
function closeAccount(){document.getElementById('accountModal').classList.add('hidden')}
async function loginWithGoogle(){
 if(!window.supabaseClient){alert('Configure o Supabase primeiro.');return}
 const {error}=await supabaseClient.auth.signInWithOAuth({provider:'google',options:{redirectTo:window.location.origin}});
 if(error)alert('Não foi possível entrar com Google: '+error.message);
}
async function logoutAccount(){if(!window.supabaseClient)return;const {error}=await supabaseClient.auth.signOut();if(error)alert(error.message);else{closeAccount();hidePendingPaymentCTA();document.getElementById('myOrdersQuick')?.classList.add('hidden')}}
function statusLabel(status){return {pending_payment:'Aguardando pagamento',paid:'Pago / em atendimento',delivered:'Entregue',cancelled:'Cancelado'}[status]||status}
function renderMyOrders(rows){
 const el=document.getElementById('myOrders'); if(!el)return;
 if(!rows?.length){el.innerHTML='<p class="muted">Você ainda não tem pedidos.</p>';return}
 el.innerHTML=rows.map(o=>`<div class="my-order"><div class="my-order-top"><b>${escapeHtml(o.ticket_code)}</b><span class="status-mini ${escapeHtml(o.status)}">${escapeHtml(statusLabel(o.status))}</span></div><small>${money(o.total)} • ${new Date(o.created_at).toLocaleString('pt-BR')}</small><small>${escapeHtml(reviewProductText(o.items))}</small>${o.ticket_closed?'<button class="btn2" disabled style="opacity:.55">TICKET FECHADO</button>':o.status==='pending_payment'?'<button class="btn2" disabled style="opacity:.55">TICKET LIBERA APÓS O PIX</button>':`<button class="btn2" onclick="openTicketById('${o.id}')">ABRIR TICKET</button>`}</div>`).join('');
}
async function showMyOrders(){
 const section=document.getElementById('myOrdersSection');
 section?.classList.remove('hidden');
 await loadMyOrders(true);
 section?.scrollIntoView({behavior:'smooth',block:'nearest'});
}
async function loadMyOrders(showList=false){
 if(!window.supabaseClient||!currentUser){hidePendingPaymentCTA();return}
 document.getElementById('myOrdersQuick')?.classList.remove('hidden');
 const el=document.getElementById('myOrders'); if(el)el.innerHTML='<p class="muted">Carregando seus pedidos...</p>';
 const {data,error}=await supabaseClient.from('orders').select('id,ticket_code,customer_name,customer_email,customer_avatar_url,items,total,status,created_at,ticket_closed,expires_at,pix_qr_code,pix_qr_base64').eq('customer_user_id',currentUser.id).order('created_at',{ascending:false}).limit(50);
 if(error){if(el)el.innerHTML='<p class="muted">Não foi possível carregar os pedidos.</p>';console.error(error);hidePendingPaymentCTA();return}
 if(showList)renderMyOrders(data||[]);
 updateOrderContinuationCTA(data||[]);
}

let pendingPaymentOrder=null,pendingPaymentUiTimer=null;
function hidePendingPaymentCTA(){
 pendingPaymentOrder=null;
 if(pendingPaymentUiTimer){clearInterval(pendingPaymentUiTimer);pendingPaymentUiTimer=null}
 document.getElementById('pendingPaymentBar')?.classList.add('hidden');
 activeTicketOrder=null;
}

let activeTicketOrder=null;
function updateOrderContinuationCTA(rows){
 if(!currentUser){hidePendingPaymentCTA();activeTicketOrder=null;return}
 const now=Date.now();
 const pending=(rows||[]).find(o=>o.status==='pending_payment'&&o.expires_at&&new Date(o.expires_at).getTime()>now);
 const active=(rows||[]).find(o=>['paid','delivered'].includes(o.status)&&!o.ticket_closed);
 const bar=document.getElementById('pendingPaymentBar');
 const text=document.getElementById('pendingPaymentText');
 const btn=document.getElementById('resumePendingPayment');
 activeTicketOrder=active||null;
 if(pending){
   pendingPaymentOrder=pending; activeTicketOrder=null; bar?.classList.remove('hidden');
   if(btn){btn.textContent='CONTINUAR PIX';btn.onclick=resumePendingPayment}
   const paint=()=>{if(!pendingPaymentOrder)return;const left=new Date(pendingPaymentOrder.expires_at).getTime()-Date.now();if(left<=0){hidePendingPaymentCTA();fetch('/api/check-payment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({order_id:pending.id})}).catch(()=>null);return}const m=Math.floor(left/60000),sec=Math.floor((left%60000)/1000);if(text)text.textContent=`PIX aguardando pagamento • expira em ${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`};
   paint();if(pendingPaymentUiTimer)clearInterval(pendingPaymentUiTimer);pendingPaymentUiTimer=setInterval(paint,1000);return;
 }
 pendingPaymentOrder=null;if(pendingPaymentUiTimer){clearInterval(pendingPaymentUiTimer);pendingPaymentUiTimer=null}
 if(active){bar?.classList.remove('hidden');if(text)text.textContent=`Você tem um atendimento aberto • ${active.ticket_code}`;if(btn){btn.textContent='CONTINUAR ATENDIMENTO';btn.onclick=resumeActiveTicket}return}
 activeTicketOrder=null;bar?.classList.add('hidden');
}
async function resumeActiveTicket(){if(!activeTicketOrder)return;localStorage.setItem('kaneki_ticket_id',activeTicketOrder.id);localStorage.setItem('kaneki_ticket_code',activeTicketOrder.ticket_code);currentOrder=activeTicketOrder;await openTicket()}
async function resumePendingPayment(){
 if(!currentUser||!pendingPaymentOrder)return;
 const {data,error}=await supabaseClient.from('orders').select('*').eq('id',pendingPaymentOrder.id).eq('customer_user_id',currentUser.id).single();
 if(error||!data){hidePendingPaymentCTA();kanekiNotice('Não foi possível localizar esse pedido.',{title:'Pedido não encontrado',type:'error'});return}
 if(data.status!=='pending_payment'){
   hidePendingPaymentCTA();
   loadMyOrders();
   if(['paid','delivered'].includes(data.status)){localStorage.setItem('kaneki_ticket_id',data.id);localStorage.setItem('kaneki_ticket_code',data.ticket_code);currentOrder=data;openTicket()}
   return;
 }
 const left=new Date(data.expires_at||0).getTime()-Date.now();
 if(left<=0){
   hidePendingPaymentCTA();
   await fetch('/api/check-payment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({order_id:data.id})}).catch(()=>null);
   kanekiNotice('Esse PIX já expirou. Gere um novo pedido para continuar.',{title:'PIX expirado',type:'info'});
   loadMyOrders();
   return;
 }
 localStorage.setItem('kaneki_ticket_id',data.id);localStorage.setItem('kaneki_ticket_code',data.ticket_code);currentOrder=data;
 document.getElementById('pixModal')?.classList.remove('hidden');
 const st=document.getElementById('pixStatus');if(st)st.textContent='Aguardando pagamento';
 const code=document.getElementById('pixCode');if(code)code.value=data.pix_qr_code||'';
 const img=document.getElementById('pixQr');if(img){img.src=data.pix_qr_base64?`data:image/png;base64,${data.pix_qr_base64}`:'';img.classList.toggle('hidden',!data.pix_qr_base64)}
 document.getElementById('pixWaiting')?.classList.remove('hidden');
 document.getElementById('pixTicketBtn')?.classList.add('hidden');
 startPixCountdown(data.id,data.expires_at);
 startPaymentWatch(data.id);
}
function openMyOrdersQuick(){
 if(!currentUser){openAccount();return}
 openAccount();
 setTimeout(()=>document.querySelector('.account-subtitle')?.scrollIntoView({behavior:'smooth',block:'start'}),120);
}

document.getElementById('resumePendingPayment')?.addEventListener('click',resumePendingPayment);
document.getElementById('myOrdersQuick')?.addEventListener('click',openMyOrdersQuick);

async function openTicketById(id){
 const row=await supabaseClient.from('orders').select('*').eq('id',id).single();
 if(row.error){alert('Pedido não encontrado.');return}
 if(row.data.ticket_closed){alert('Este atendimento já foi encerrado pela KANEKI STORE.');return}
 if(!['paid','delivered'].includes(row.data.status)){
   if(row.data.status==='cancelled'){localStorage.removeItem('kaneki_ticket_id');localStorage.removeItem('kaneki_ticket_code');alert('Este pedido foi cancelado porque o pagamento expirou. Gere um novo pedido para receber atendimento.');}
   else alert('Seu ticket será liberado somente após a confirmação do pagamento PIX.');
   return
 }
 localStorage.setItem('kaneki_ticket_id',id);localStorage.setItem('kaneki_ticket_code',row.data.ticket_code);currentOrder=row.data;openTicket();closeAccount();
}

document.getElementById('accountOpen')?.addEventListener('click',openAccount);

// ===== KANEKI: pedidos, ticket e avaliações =====
let currentOrder=null, ticketChannel=null, reviewRating=5;
function ticketId(){return localStorage.getItem('kaneki_ticket_id')}
function ticketCode(){return localStorage.getItem('kaneki_ticket_code')}
let pendingNick='',paymentPoll=null,checkoutBusy=false;
async function startCheckout(){
 if(!cart.length){alert('Seu carrinho está vazio.');return}
 if(!window.supabaseClient){alert('Configure o Supabase primeiro.');return}
 if(!currentUser){openAccount();kanekiNotice('Entre com sua conta Google/Gmail para continuar a compra.',{title:'Entre para continuar',icon:'G',type:'info'});return}
 const ids=cart.map(x=>x.id);
 const {data:live,error:stockErr}=await supabaseClient.from('products').select('id,name,price,stock,reserved_stock,active').in('id',ids);
 if(stockErr){alert('Não foi possível conferir o estoque: '+stockErr.message);return}
 const liveMap=new Map((live||[]).map(p=>[Number(p.id),p]));
 for(const x of cart){const p=liveMap.get(Number(x.id));if(!p||!p.active){alert(x.name+' não está disponível.');return}const available=Math.max(0,(Number(p.stock)||0)-(Number(p.reserved_stock)||0));if(available<x.qty){alert('Estoque insuficiente para '+x.name+'. Disponível: '+available);return}}
 document.getElementById('gameNick').value='';
 document.getElementById('checkoutSummary').innerHTML='<b>Seu pedido</b><br>'+cart.map(x=>escapeHtml(x.name)+' × '+x.qty).join('<br>')+'<br><br><b>Total: '+money(cart.reduce((s,x)=>s+x.price*x.qty,0))+'</b>';
 closeCart();document.getElementById('nickModal').classList.remove('hidden');
}
function closeNickModal(){document.getElementById('nickModal').classList.add('hidden')}
function continueToPayment(){
 const nick=document.getElementById('gameNick').value.trim();
 if(nick.length<2){alert('Digite seu Nick no jogo.');return}
 pendingNick=nick;closeNickModal();document.getElementById('paymentMethodModal').classList.remove('hidden');
}
function closePaymentMethod(){document.getElementById('paymentMethodModal').classList.add('hidden')}
async function confirmPixOrder(){if(checkoutBusy)return;checkoutBusy=true;closePaymentMethod();try{await createOrder('pix')}finally{checkoutBusy=false}}
async function createOrder(paymentMethod='pix'){
 if(!cart.length||!currentUser||!pendingNick)return;
 const name=accountNameFromUser(currentUser), email=currentUser.email;
 if(!email){alert('Sua conta Google não possui e-mail disponível.');return}
 const ids=cart.map(x=>x.id);const {data:live,error:stockErr}=await supabaseClient.from('products').select('id,name,price,stock,reserved_stock,active').in('id',ids);if(stockErr){alert('Não foi possível conferir o estoque: '+stockErr.message);return}const liveMap=new Map((live||[]).map(p=>[Number(p.id),p]));for(const x of cart){const p=liveMap.get(Number(x.id));if(!p||!p.active){alert(x.name+' não está disponível.');return}const available=Math.max(0,(Number(p.stock)||0)-(Number(p.reserved_stock)||0));if(available<x.qty){alert('Estoque insuficiente para '+x.name+'. Disponível: '+available);return}}
 const items=cart.map(x=>({id:x.id,name:x.name,price:x.price,qty:x.qty})); const total=cart.reduce((s,x)=>s+x.price*x.qty,0);
 const code='KNK-'+Math.random().toString(36).slice(2,7).toUpperCase()+'-'+Math.random().toString(36).slice(2,6).toUpperCase();
 const avatar=currentUser?.user_metadata?.avatar_url||currentUser?.user_metadata?.picture||'';
 const {data,error}=await supabaseClient.from('orders').insert({ticket_code:code,customer_name:name,customer_contact:pendingNick,customer_email:email,customer_avatar_url:avatar,customer_user_id:currentUser.id,items,total,payment_provider:paymentMethod,expires_at:new Date(Date.now()+CART_TTL_MS).toISOString()}).select().single();
 if(error){alert('Não foi possível criar o pedido: '+error.message);return}
 localStorage.setItem('kaneki_ticket_id',data.id); localStorage.setItem('kaneki_ticket_code',data.ticket_code); currentOrder=data;
 const pixOk=await createPixPayment(data.id,email);
 if(pixOk){cart=[];localStorage.removeItem('kaneki_cart_expires_at');saveCart();renderCart();pendingNick='';startPaymentWatch(data.id);loadMyOrders()}
}
let pixCountdownTimer=null,pixExpiresAt=0;
async function createPixPayment(orderId,email){
 try{const {data:{session}}=await supabaseClient.auth.getSession();const r=await fetch('/api/create-pix',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${session?.access_token||''}`},body:JSON.stringify({order_id:orderId})});const data=await r.json();if(!r.ok||data.error)throw new Error(data.error||'Não foi possível gerar o Pix.');
 document.getElementById('pixModal').classList.remove('hidden');document.getElementById('pixStatus').textContent='Aguardando pagamento';document.getElementById('pixCode').value=data.qr_code||'';
 const img=document.getElementById('pixQr');img.src=data.qr_code_base64?`data:image/png;base64,${data.qr_code_base64}`:'';img.classList.toggle('hidden',!data.qr_code_base64);startPixCountdown(orderId,data.expires_at);return true;
 }catch(e){alert(e.message+'\n\nO PIX não pôde ser gerado. Seu estoque não ficará preso.');return false}
}
function startPixCountdown(orderId,expiresAt){pixExpiresAt=new Date(expiresAt||Date.now()+CART_TTL_MS).getTime();if(pixCountdownTimer)clearInterval(pixCountdownTimer);const tick=async()=>{const left=Math.max(0,pixExpiresAt-Date.now()),m=Math.floor(left/60000),sec=Math.floor((left%60000)/1000);const el=document.getElementById('pixCountdown');if(el)el.textContent=`⏱️ Este PIX expira em ${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;if(left<=0){clearInterval(pixCountdownTimer);pixCountdownTimer=null;const {data:{session}}=await supabaseClient.auth.getSession();await fetch('/api/check-payment',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${session?.access_token||''}`},body:JSON.stringify({order_id:orderId})}).catch(()=>null);cart=[];localStorage.removeItem('kaneki_cart');localStorage.removeItem('kaneki_cart_expires_at');renderCart();closeCart();document.getElementById('pixModal').classList.add('hidden');kanekiNotice('O PIX expirou. A reserva do estoque foi liberada.',{title:'Pagamento expirado',type:'info'})}};tick();pixCountdownTimer=setInterval(tick,1000)}
function closePix(){document.getElementById('pixModal').classList.add('hidden');if(paymentPoll){clearInterval(paymentPoll);paymentPoll=null}if(pixCountdownTimer){clearInterval(pixCountdownTimer);pixCountdownTimer=null}}
function startPaymentWatch(orderId){if(paymentPoll)clearInterval(paymentPoll);let checking=false;paymentPoll=setInterval(async()=>{if(checking)return;checking=true;try{const {data:{session}}=await supabaseClient.auth.getSession();await fetch('/api/check-payment',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${session?.access_token||''}`},body:JSON.stringify({order_id:orderId})}).catch(()=>null);const {data}=await supabaseClient.from('orders').select('*').eq('id',orderId).single();if(!data)return;if(data.status==='cancelled'){clearInterval(paymentPoll);paymentPoll=null;hidePendingPaymentCTA();loadMyOrders();const st=document.getElementById('pixStatus');if(st)st.textContent='⌛ PIX expirado/cancelado. Gere um novo pedido.';return}if(['paid','delivered'].includes(data.status)){clearInterval(paymentPoll);paymentPoll=null;hidePendingPaymentCTA();currentOrder=data;const st=document.getElementById('pixStatus');if(st)st.textContent='✅ Pagamento confirmado pelo Mercado Pago! Abrindo seu atendimento...';document.getElementById('pixWaiting')?.classList.add('hidden');document.getElementById('pixTicketBtn')?.classList.remove('hidden');loadMyOrders();setTimeout(async()=>{closePix();await openTicket()},600)}}finally{checking=false}},2500)}
async function copyPix(){const v=document.getElementById('pixCode').value;if(!v)return;await navigator.clipboard?.writeText(v);document.getElementById('pixCopy').textContent='COPIADO!';setTimeout(()=>document.getElementById('pixCopy').textContent='COPIAR PIX',1500)}
async function openTicket(){
 const id=ticketId(); if(!id||!window.supabaseClient){alert('Nenhum ticket encontrado neste aparelho.');return}
 if(!currentUser){openAccount();alert('Entre com sua conta Google para acessar o ticket.');return}
 const {data,error}=await supabaseClient.from('orders').select('*').eq('id',id).eq('customer_user_id',currentUser.id).single(); if(error){alert('Ticket não encontrado para esta conta.');return}
 if(data.ticket_closed){localStorage.removeItem('kaneki_ticket_id');localStorage.removeItem('kaneki_ticket_code');alert('Este atendimento já foi encerrado pela KANEKI STORE.');loadMyOrders();return}
 if(!['paid','delivered'].includes(data.status)){
   localStorage.removeItem('kaneki_ticket_id');localStorage.removeItem('kaneki_ticket_code');
   if(data.status==='cancelled')alert('Este pedido foi cancelado porque o PIX expirou. O ticket não está mais disponível.');
   else alert('Seu ticket será liberado somente após a confirmação do pagamento PIX.');
   loadMyOrders();return
 }
 currentOrder=data; document.getElementById('ticketModal').classList.remove('hidden'); updateTicketUI(); await loadMessages();
 if(ticketChannel)await supabaseClient.removeChannel(ticketChannel);
 ticketChannel=supabaseClient.channel('ticket-'+id).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:'order_id=eq.'+id},payload=>appendMessage(payload.new)).on('postgres_changes',{event:'UPDATE',schema:'public',table:'orders',filter:'id=eq.'+id},payload=>{currentOrder=payload.new;updateTicketUI()}).on('broadcast',{event:'typing'},({payload})=>{const el=document.getElementById('ticketTyping');if(el&&payload?.from==='admin'){el.textContent=payload.typing?'KANEKI STORE está digitando...':''}}).subscribe();
}
function closeTicket(){document.getElementById('ticketModal').classList.add('hidden')}
function orderIsDelivered(o){return !!o&&(o.status==='delivered'||o.fulfillment_status==='delivered')}
function updateTicketUI(){const delivered=orderIsDelivered(currentOrder);const statusKey=delivered?'delivered':currentOrder.status;const s={pending_payment:siteTexts.ticket_pending||'Aguardando confirmação do pagamento.',paid:siteTexts.ticket_paid||'Pagamento confirmado. Fale com a KANEKI STORE para combinar a entrega.',delivered:siteTexts.ticket_delivered||'Pedido entregue. Obrigado pela compra!',cancelled:'Pedido cancelado.'}[statusKey]||statusKey;const nick=currentOrder.customer_contact||'Cliente';document.getElementById('ticketStatus').innerHTML='<b>Ticket '+escapeHtml(currentOrder.ticket_code)+'</b> — '+s;const cn=document.getElementById('ticketCustomerName');if(cn)cn.textContent=nick;const ce=document.getElementById('ticketCustomerEmail');if(ce)ce.textContent=currentOrder.customer_email||currentUser?.email||'';const ca=document.getElementById('ticketCustomerAvatar');if(ca){const url=currentOrder.customer_avatar_url||currentUser?.user_metadata?.avatar_url||currentUser?.user_metadata?.picture||'';ca.src=url||'/assets/logo.svg';ca.style.opacity=url?'1':'.45'}if(delivered)checkExistingReview();else document.getElementById('reviewBox').classList.add('hidden')}
async function checkExistingReview(){const {data}=await supabaseClient.from('reviews').select('id').eq('order_id',currentOrder.id).maybeSingle();const box=document.getElementById('reviewBox');const show=!data;box.classList.toggle('hidden',!show);if(show){requestAnimationFrame(()=>{const chat=document.getElementById('ticketMessages');if(chat)chat.scrollTop=chat.scrollHeight;box.scrollTop=0;});}}
async function loadMessages(){const {data}=await supabaseClient.from('messages').select('*').eq('order_id',currentOrder.id).order('created_at');document.getElementById('ticketMessages').innerHTML='';(data||[]).forEach(appendMessage)}
async function appendMessage(m){const box=document.getElementById('ticketMessages');if(!box)return;const d=document.createElement('div');d.className='bubble '+m.sender;let media='';if(m.image_path){const {data}=await supabaseClient.storage.from('ticket-images').createSignedUrl(m.image_path,3600);if(data?.signedUrl)media=`<a href="${data.signedUrl}" target="_blank"><img class="chat-image" src="${data.signedUrl}" alt="Imagem do ticket"></a>`}const isAdmin=m.sender==='admin';const avatar=isAdmin?(siteTexts.store_avatar||'/assets/logo.svg'):(currentOrder?.customer_avatar_url||currentUser?.user_metadata?.avatar_url||currentUser?.user_metadata?.picture||'');const label=isAdmin?'KANEKI STORE':(currentOrder?.customer_contact||'Cliente');const sub=isAdmin?'Loja • Atendimento oficial':(currentOrder?.customer_email||currentUser?.email||'Cliente');d.innerHTML=`<div class="msg-profile">${avatar?`<img src="${escapeHtml(avatar)}" alt="">`:'<span class="msg-avatar-fallback">👤</span>'}<div><b>${escapeHtml(label)}</b><small>${escapeHtml(sub)}</small></div></div>${m.message?`<span class="msg-text">${escapeHtml(m.message)}</span>`:''}${media}<small class="msg-time">${new Date(m.created_at).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</small>`;box.appendChild(d);box.scrollTop=box.scrollHeight}
async function uploadCustomerImage(ev){const file=ev.target.files?.[0];ev.target.value='';if(!file||!currentOrder)return;if(currentOrder.ticket_closed){alert('Este ticket já foi fechado.');return;}if(!file.type.startsWith('image/')){alert('Envie somente imagens.');return}if(file.size>8*1024*1024){alert('A imagem deve ter no máximo 8 MB.');return}const ext=(file.name.split('.').pop()||'jpg').replace(/[^a-z0-9]/gi,'');const path=`${currentOrder.id}/${currentUser.id}/${Date.now()}-${crypto.randomUUID()}.${ext}`;const {error:upErr}=await supabaseClient.storage.from('ticket-images').upload(path,file,{contentType:file.type,upsert:false});if(upErr){alert('Não foi possível enviar a imagem: '+upErr.message);return}const {error}=await supabaseClient.from('messages').insert({order_id:currentOrder.id,sender:'customer',message:'',image_path:path});if(error)alert(error.message)}
let ticketTypingTimer=null;function ticketTyping(){if(!ticketChannel)return;ticketChannel.send({type:'broadcast',event:'typing',payload:{from:'customer',typing:true}});clearTimeout(ticketTypingTimer);ticketTypingTimer=setTimeout(()=>ticketChannel?.send({type:'broadcast',event:'typing',payload:{from:'customer',typing:false}}),900)}
async function sendCustomerMessage(){const input=document.getElementById('ticketMessage'),message=input.value.trim();if(!message||!currentOrder)return;if(currentOrder.ticket_closed){alert('Este ticket já foi fechado.');return;}const {error}=await supabaseClient.from('messages').insert({order_id:currentOrder.id,sender:'customer',message});if(error)alert(error.message);else{input.value='';ticketChannel?.send({type:'broadcast',event:'typing',payload:{from:'customer',typing:false}})}}
let publicReviews=[];
let reviewDisplaySettings={enabled:true,speed:32,pause:true,size:'normal',verified:true};
let reviewResizeTimer=null;
function boolSetting(v,def=true){if(v===undefined||v===null||v==='')return def;return String(v).toLowerCase()!=='false'}
function reviewProductText(items){const names=(items||[]).map(i=>`${i.name}${Number(i.qty)>1?' × '+i.qty:''}`);if(!names.length)return 'Compra na KANEKI STORE';return names.length>2?names.slice(0,2).join(', ')+' + mais':names.join(', ')}
function reviewCardHtml(r){
 const verified=reviewDisplaySettings.verified?'<span>Cliente verificado</span>':'';
 const date=r.created_at?new Date(r.created_at).toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'}):'';
 const reviewId=String(r.id??'').replace(/[^0-9]/g,'');
 return `<article class="review-card"><div class="review-head">${r.customer_avatar_url?`<img class="review-avatar" src="${escapeHtml(r.customer_avatar_url)}" alt="">`:'<div class="review-avatar review-avatar-fallback">★</div>'}<div class="review-person"><b>${escapeHtml(r.customer_name)}</b>${date?`<small>${escapeHtml(date)}</small>`:''}</div>${verified}</div><p class="review-comment">“${escapeHtml(r.comment)}”</p><div class="stars">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</div><div class="review-bought"><div class="review-product-copy"><small>COMPROU</small><strong>${escapeHtml(reviewProductText(r.purchased_items||r.items))}</strong></div><button type="button" class="review-view" onclick="buyFromReview(${reviewId||'0'})">Ver ›</button></div></article>`;
}
function normalizeProductName(v){return String(v||'').trim().toLowerCase().replace(/\s+/g,' ')}
function buyFromReview(reviewId){
 const r=publicReviews.find(x=>Number(x.id)===Number(reviewId));
 if(!r)return;
 const items=Array.isArray(r.purchased_items)?r.purchased_items:(Array.isArray(r.items)?r.items:[]);
 if(!items.length){document.getElementById('produtos')?.scrollIntoView({behavior:'smooth',block:'start'});return}
 let added=0;
 for(const item of items){
   const byId=products.find(p=>Number(p.id)===Number(item.id));
   const target=byId||products.find(p=>normalizeProductName(p.name)===normalizeProductName(item.name));
   if(!target)continue;
   const available=Math.max(0,Number(target.stock)||0);
   if(available<=0)continue;
   const existing=cart.find(c=>Number(c.id)===Number(target.id));
   const wanted=Math.max(1,Number(item.qty)||1);
   const current=Number(existing?.qty||0);
   const next=Math.min(available,current+wanted);
   if(next<=current)continue;
   if(existing)existing.qty=next;else cart.push({...target,qty:next});
   added+=next-current;
 }
 if(added>0){saveCart();renderCart();openCart()}
 else{alert('Esse produto não está disponível no momento.');document.getElementById('produtos')?.scrollIntoView({behavior:'smooth',block:'start'})}
}
function applyReviewSettings(){
 const root=document.getElementById('avaliacoes'),track=document.getElementById('reviewsTrack');if(!root||!track)return;
 const base=Math.max(8,Math.min(120,Number(reviewDisplaySettings.speed)||32));
 const cards=Math.max(1,publicReviews.length);
 const duration=Math.max(8,Math.round(base*Math.max(1,cards/2)));
 root.classList.toggle('reviews-static',!reviewDisplaySettings.enabled);
 root.classList.toggle('reviews-pause-hover',!!reviewDisplaySettings.pause);
 root.dataset.cardSize=reviewDisplaySettings.size||'normal';
 track.style.setProperty('--review-speed',`${duration}s`);
 if(reviewDisplaySettings.enabled&&!track.classList.contains('is-empty')){
   track.style.animation='none'; void track.offsetWidth; track.style.animation='';
 }
}
async function loadReviews(){
 if(!window.supabaseClient)return;
 const [{data,error},{data:settings}]=await Promise.all([
   supabaseClient.from('reviews').select('*').eq('approved',true).order('created_at',{ascending:false}).limit(30),
   supabaseClient.from('site_settings').select('key,value').in('key',['review_marquee_enabled','review_marquee_speed','review_pause_hover','review_card_size','review_show_verified'])
 ]);
 if(error){console.error(error);return}
 const map={};(settings||[]).forEach(r=>map[r.key]=r.value);
 reviewDisplaySettings={enabled:boolSetting(map.review_marquee_enabled,true),speed:Number(map.review_marquee_speed||32),pause:boolSetting(map.review_pause_hover,true),size:map.review_card_size||'normal',verified:boolSetting(map.review_show_verified,true)};
 publicReviews=(data||[]).map(r=>({...r,items:r.purchased_items||[]}));
 renderReviews();
}
let reviewSettingsChannel=null;
function subscribeReviewSettings(){
 if(!window.supabaseClient||reviewSettingsChannel)return;
 reviewSettingsChannel=supabaseClient.channel('kaneki-review-settings-live')
   .on('postgres_changes',{event:'*',schema:'public',table:'site_settings'},payload=>{
     const key=payload?.new?.key||payload?.old?.key||'';
     if(['review_marquee_enabled','review_marquee_speed','review_pause_hover','review_card_size','review_show_verified'].includes(key))loadReviews();
   })
   .on('postgres_changes',{event:'*',schema:'public',table:'reviews'},()=>loadReviews())
   .subscribe();
}
function renderReviews(){
 const el=document.getElementById('reviewsTrack'),dots=document.getElementById('reviewDots');if(!el)return;
 if(!publicReviews.length){el.className='reviews-track reviews-marquee-track is-empty';el.innerHTML='<p class="muted review-empty">As avaliações dos clientes aparecerão aqui.</p>';if(dots)dots.innerHTML='';return}
 const cards=publicReviews.map(reviewCardHtml).join('');
 const duplicated=publicReviews.length>1?cards+cards:cards;
 el.className='reviews-track reviews-marquee-track';
 el.innerHTML=duplicated;
 if(dots)dots.innerHTML='';
 applyReviewSettings();
}
window.reviewGo=()=>{};window.reviewNext=()=>{};window.reviewPrev=()=>{};
async function submitReview(){if(!currentOrder||!currentUser)return;const {data:latestOrder,error:orderErr}=await supabaseClient.from('orders').select('*').eq('id',currentOrder.id).eq('customer_user_id',currentUser.id).single();if(!orderErr&&latestOrder){currentOrder=latestOrder;updateTicketUI()}if(!orderIsDelivered(currentOrder)){alert('A avaliação só é liberada depois que o dono confirmar a entrega.');return}const name=document.getElementById('reviewName').value.trim()||currentOrder.customer_name,comment=document.getElementById('reviewComment').value.trim();if(!comment){alert('Escreva um comentário.');return}const avatar=currentOrder.customer_avatar_url||currentUser?.user_metadata?.avatar_url||currentUser?.user_metadata?.picture||'';const {error}=await supabaseClient.from('reviews').insert({order_id:currentOrder.id,customer_name:name,rating:reviewRating,comment,purchased_items:currentOrder.items,customer_user_id:currentUser.id,customer_avatar_url:avatar,approved:false});if(error){if(error.code==='23505')alert('Você já avaliou este pedido.');else alert('Não foi possível enviar a avaliação: '+error.message)}else{alert('Avaliação enviada! Ela aparecerá após aprovação do dono.');document.getElementById('reviewBox').classList.add('hidden');loadReviews()}}
window.setReviewRating=r=>{reviewRating=Math.max(1,Math.min(5,Number(r)||5));document.querySelectorAll('#stars button').forEach((b,i)=>b.classList.toggle('active',i<reviewRating))};

// ===== V9: textos editáveis pelo ADM =====
const SITE_TEXT_DEFAULTS={store_name:'KANEKI STORE',store_avatar:'/assets/kaneki-logo-round.png',google_icon:'/assets/google-g.svg',pix_icon:'/assets/pix.svg',banner_image:'/assets/banner-placeholder.svg',hero_eyebrow:'KANEKI STORE',hero_title:'Os melhores produtos para Blox Fruits',hero_subtitle:'Atendimento privado • Entrega feita pelo dono • PIX',hero_button:'COMPRAR AGORA',reviews_eyebrow:'CLIENTES KANEKI',reviews_title:'O que nossos clientes dizem',products_eyebrow:'CATÁLOGO BLOX FRUITS',products_title:'Produtos',account_login_title:'Entrar na KANEKI STORE',account_login_subtitle:'Crie sua conta ou entre usando sua conta Google/Gmail.',google_button_text:'Continuar com Google',nick_title:'🎮 Qual é seu Nick?',nick_subtitle:'Informe o Nick da sua conta no Roblox/Blox Fruits para receber seu produto.',nick_placeholder:'Seu Nick no Roblox/Blox Fruits',nick_button:'CONTINUAR',payment_title:'💳 Escolha o pagamento',payment_subtitle:'Seu Nick foi confirmado. Agora escolha como deseja pagar.',pix_label:'PIX',pix_subtitle:'Pagamento rápido e confirmação automática',pix_title:'⚡ PIX gerado na hora',pix_waiting:'⏳ Assim que o pagamento for confirmado, o ticket será liberado aqui.',ticket_title:'Seu ticket de atendimento',cart_help:'Pagamento via Pix. Após a confirmação, seu ticket de atendimento será liberado automaticamente.',ticket_pending:'Aguardando confirmação do pagamento.',ticket_paid:'Pagamento confirmado. Fale com o dono para combinar a entrega.',ticket_delivered:'Pedido entregue. Obrigado pela compra!',footer_brand:'KANEKI STORE',footer_contact:'Discord.gg/Kanekistore',top_account_icon:'/assets/google-g.svg',top_cart_text:'Carrinho',top_cart_icon:'',side_orders_text:'Meus pedidos',side_orders_icon:'',side_discord_text:'Discord',side_discord_icon:'/assets/discord.png',side_discord_link:'https://discord.gg/kanekistore',side_whatsapp_text:'WhatsApp',side_whatsapp_icon:'',side_whatsapp_link:'https://wa.me/5591993285862',side_chat_text:'Chat geral',side_chat_icon:'',benefit1_title:'Ticket privado',benefit1_desc:'Converse com o dono após a compra.',benefit1_icon:'',benefit2_title:'Compra organizada',benefit2_desc:'Seu pedido fica registrado.',benefit2_icon:'',benefit3_title:'Atendimento rápido',benefit3_desc:'Entrega feita pelo responsável.',benefit3_icon:'',benefit4_title:'Avaliações',benefit4_desc:'Veja a experiência de outros clientes.',benefit4_icon:'',faq_title:'Perguntas frequentes',faq_q1:'Como funciona a entrega?',faq_a1:'Após a confirmação do pagamento, seu pedido recebe um ticket privado. Você conversa com o dono da KANEKI STORE por esse ticket e combina a entrega. Quando finalizar, o pedido é marcado como entregue.',faq_q2:'Como acompanho meu pedido?',faq_a2:'Depois de criar o pedido, guarde o código do ticket. Ele abre a conversa privada do pedido neste site.',faq_q3:'Posso avaliar a compra?',faq_a3:'Sim. Depois que o pedido for marcado como entregue, você poderá deixar uma nota e comentário. As avaliações aprovadas aparecem abaixo do banner.',support_title:'SUPORTE KANEKI',support_subtitle:'Atendimento rápido pelo WhatsApp',support_icon:'',support_whatsapp_label:'Falar no WhatsApp',support_whatsapp_number:'(91) 99328-5862',support_whatsapp_link:'https://wa.me/5591993285862'};
SITE_TEXT_DEFAULTS.support_icon='/assets/whatsapp.svg';
let siteTexts={...SITE_TEXT_DEFAULTS};
function setText(id,v){const e=document.getElementById(id);if(e&&v!==undefined)e.textContent=v}
function setImg(id,v){const e=document.getElementById(id);if(e&&v)e.src=v}
function applyConfigIcon(imgId,fallbackId,url){const img=document.getElementById(imgId),fb=document.getElementById(fallbackId);const v=String(url||'').trim();if(img){if(v){img.src=v;img.classList.remove('hidden')}else{img.removeAttribute('src');img.classList.add('hidden')}}if(fb)fb.classList.toggle('hidden',!!v)}
function setHref(id,url){const e=document.getElementById(id);if(e&&String(url||'').trim())e.href=String(url).trim()}
async function loadSiteTexts(){if(!window.supabaseClient)return;const {data,error}=await supabaseClient.from('site_settings').select('key,value');if(error){console.warn('site_settings:',error.message);return}siteTexts={...SITE_TEXT_DEFAULTS};(data||[]).forEach(r=>siteTexts[r.key]=r.value);setText('storeName',siteTexts.store_name);document.querySelectorAll('.js-store-name').forEach(e=>e.textContent=siteTexts.store_name);const storeAvatarUrl=(siteTexts.store_avatar==='/assets/logo.svg'||!String(siteTexts.store_avatar||'').trim())?'/assets/kaneki-logo-round.png':siteTexts.store_avatar;setImg('storeAvatar',storeAvatarUrl);document.querySelectorAll('.js-store-avatar').forEach(e=>e.src=storeAvatarUrl);setImg('googleHeaderIcon',siteTexts.top_account_icon||siteTexts.google_icon);setImg('googleLoginIcon',siteTexts.google_icon);setImg('googleButtonIcon',siteTexts.google_icon);setImg('pixOptionIcon',siteTexts.pix_icon);setImg('heroBanner',siteTexts.banner_image);setText('heroEyebrow',siteTexts.hero_eyebrow);setText('heroTitle',siteTexts.hero_title);setText('heroSubtitle',siteTexts.hero_subtitle);setText('heroButton',siteTexts.hero_button);setText('reviewsEyebrow',siteTexts.reviews_eyebrow);setText('reviewsTitle',siteTexts.reviews_title);setText('productsEyebrow',siteTexts.products_eyebrow);setText('productsTitle',siteTexts.products_title);setText('accountLoginTitle',siteTexts.account_login_title);setText('accountLoginSubtitle',siteTexts.account_login_subtitle);setText('googleButtonText',siteTexts.google_button_text);setText('nickTitle',siteTexts.nick_title);setText('nickSubtitle',siteTexts.nick_subtitle);const gn=document.getElementById('gameNick');if(gn)gn.placeholder=siteTexts.nick_placeholder;setText('nickButton',siteTexts.nick_button);setText('paymentTitle',siteTexts.payment_title);setText('paymentSubtitle',siteTexts.payment_subtitle);setText('pixLabel',siteTexts.pix_label);setText('pixSubtitle',siteTexts.pix_subtitle);setText('pixTitle',siteTexts.pix_title);setText('pixWaiting',siteTexts.pix_waiting);setText('ticketTitle',siteTexts.ticket_title);setText('cartHelp',siteTexts.cart_help);setText('footerBrand',siteTexts.footer_brand);setText('footerContact',siteTexts.footer_contact);setText('topCartText',siteTexts.top_cart_text);setText('sideOrdersText',siteTexts.side_orders_text);setText('sideDiscordText',siteTexts.side_discord_text);setText('sideWhatsappText',siteTexts.side_whatsapp_text);setText('sideChatText',siteTexts.side_chat_text);applyConfigIcon('topCartIconImg',null,siteTexts.top_cart_icon);const tcf=document.getElementById('topCartFallback');if(tcf)tcf.style.display=String(siteTexts.top_cart_icon||'').trim()?'none':'';applyConfigIcon('sideOrdersIconImg',null,siteTexts.side_orders_icon);applyConfigIcon('sideDiscordIconImg',null,siteTexts.side_discord_icon);applyConfigIcon('sideWhatsappIconImg',null,siteTexts.side_whatsapp_icon);applyConfigIcon('sideChatIconImg',null,siteTexts.side_chat_icon);setHref('sideDiscordLink',siteTexts.side_discord_link);setHref('sideWhatsappLink',siteTexts.side_whatsapp_link);setText('faqTitle',siteTexts.faq_title);setText('faqQ1',siteTexts.faq_q1);setText('faqA1',siteTexts.faq_a1);setText('faqQ2',siteTexts.faq_q2);setText('faqA2',siteTexts.faq_a2);setText('faqQ3',siteTexts.faq_q3);setText('faqA3',siteTexts.faq_a3);setText('supportTitle',siteTexts.support_title);setText('supportSubtitle',siteTexts.support_subtitle);setText('supportWhatsappLabel',siteTexts.support_whatsapp_label);setText('supportWhatsappNumber',siteTexts.support_whatsapp_number);setHref('supportWhatsappLink',siteTexts.support_whatsapp_link);const si=document.getElementById('supportIconImg'),sf=document.getElementById('supportIconFallback'),su=String(siteTexts.support_icon||'').trim();if(si){if(su){si.src=su;si.classList.remove('hidden')}else{si.removeAttribute('src');si.classList.add('hidden')}}if(sf)sf.style.display=su?'none':'';for(let i=1;i<=4;i++){setText(`benefit${i}Title`,siteTexts[`benefit${i}_title`]);setText(`benefit${i}Desc`,siteTexts[`benefit${i}_desc`]);const img=document.getElementById(`benefit${i}Img`),emoji=document.getElementById(`benefit${i}Emoji`),url=String(siteTexts[`benefit${i}_icon`]||'').trim();if(img){if(url){img.src=url;img.classList.remove('hidden')}else{img.removeAttribute('src');img.classList.add('hidden')}}if(emoji)emoji.style.display=url?'none':'';}[['heroEyebrow',siteTexts.hero_eyebrow],['heroTitle',siteTexts.hero_title],['heroSubtitle',siteTexts.hero_subtitle],['heroButton',siteTexts.hero_button]].forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.style.display=String(v||'').trim()?'':'none'});}
loadSiteTexts().then(()=>{const icon=document.getElementById('supportButtonIcon');if(icon)icon.src=String(siteTexts.support_icon||'').trim()||'/assets/whatsapp.svg'});
loadReviews();
subscribeReviewSettings();
if(document.getElementById('stars'))setReviewRating(5);

/* ===== V12.17.22 - RECOLHER ATALHOS LATERAIS ===== */
const quickSupportDock=document.querySelector('.quick-support-dock');
const quickSupportToggle=document.getElementById('quickSupportToggle');
function setQuickSupportCollapsed(collapsed,persist=true){
 if(!quickSupportDock||!quickSupportToggle)return;
 quickSupportDock.classList.toggle('is-collapsed',collapsed);
 quickSupportToggle.setAttribute('aria-expanded',String(!collapsed));
 quickSupportToggle.setAttribute('aria-label',collapsed?'Mostrar atalhos':'Ocultar atalhos');
 quickSupportToggle.title=collapsed?'Mostrar atalhos':'Ocultar atalhos';
 if(persist){try{localStorage.setItem('kaneki_quick_support_collapsed',collapsed?'1':'0')}catch(_){}}
}
if(quickSupportToggle){
 let saved=false;try{saved=localStorage.getItem('kaneki_quick_support_collapsed')==='1'}catch(_){}
 setQuickSupportCollapsed(saved,false);
 quickSupportToggle.addEventListener('click',()=>setQuickSupportCollapsed(!quickSupportDock.classList.contains('is-collapsed')));
}

/* ===== V12.17 - CONTA KANEKI + PERFIL PUBLICO + CHAT GERAL ===== */
let kanekiPublicProfile=null;
let generalChatChannel=null;
let generalChatPollTimer=null;
let generalChatOpenState=false;
let generalChatMutedState=false;
let profileLoadForUser='';
function publicNameFallback(){const m=currentUser?.user_metadata||{};return String(m.full_name||m.name||currentUser?.email?.split('@')[0]||'Cliente KANEKI').slice(0,28)}
function publicAvatarFallback(){return currentUser?.user_metadata?.avatar_url||currentUser?.user_metadata?.picture||''}
async function ensurePublicProfile(force=false){if(!currentUser||!window.supabaseClient)return null;if(!force&&kanekiPublicProfile&&profileLoadForUser===currentUser.id)return kanekiPublicProfile;profileLoadForUser=currentUser.id;const {data,error}=await supabaseClient.from('profiles').select('user_id,display_name,avatar_url,created_at,updated_at').eq('user_id',currentUser.id).maybeSingle();if(error){console.warn('profiles:',error.message);return null}if(data){kanekiPublicProfile=data;applyPublicProfileUI();return data}const seed={user_id:currentUser.id,display_name:publicNameFallback(),avatar_url:publicAvatarFallback()};const ins=await supabaseClient.from('profiles').insert(seed).select('user_id,display_name,avatar_url,created_at,updated_at').single();if(ins.error){console.warn('profile insert:',ins.error.message);return null}kanekiPublicProfile=ins.data;applyPublicProfileUI();return kanekiPublicProfile}
function applyPublicProfileUI(){if(!currentUser)return;const name=kanekiPublicProfile?.display_name||publicNameFallback(),photo=kanekiPublicProfile?.avatar_url||publicAvatarFallback();const nameEl=document.getElementById('accountName');if(nameEl)nameEl.textContent=name;const av=document.getElementById('accountAvatar');if(av){if(photo){av.textContent='';av.style.backgroundImage=`url("${String(photo).replace(/"/g,'%22')}")`;av.classList.add('has-photo')}else{av.style.backgroundImage='';av.classList.remove('has-photo');av.textContent=name.charAt(0).toUpperCase()}}const prev=document.getElementById('profileAvatarPreview');if(prev){if(photo){prev.textContent='';prev.style.backgroundImage=`url("${String(photo).replace(/"/g,'%22')}")`}else{prev.style.backgroundImage='';prev.textContent=name.charAt(0).toUpperCase()}}const input=document.getElementById('profileDisplayName');if(input)input.value=name;const url=document.getElementById('profileAvatarUrl');if(url)url.value=photo||'';const h=document.getElementById('googleHeaderIcon');if(h){h.style.display='';h.classList.add('user-photo');if(photo)h.src=photo;else h.src=siteTexts.top_account_icon||siteTexts.google_icon||'/assets/google-g.svg';h.alt=name}}

updateAccountUI=function(){const label=document.getElementById('accountLabel'),out=document.getElementById('accountLoggedOut'),inn=document.getElementById('accountLoggedIn'),gIcon=document.getElementById('googleHeaderIcon');if(!label)return;if(currentUser){label.textContent='Minha conta';if(gIcon){gIcon.style.display='';gIcon.classList.add('user-photo');const fallback=publicAvatarFallback();if(fallback)gIcon.src=fallback}if(out)out.classList.add('hidden');if(inn)inn.classList.remove('hidden');document.getElementById('sideGeneralChat')?.classList.remove('hidden');ensurePublicProfile().then(()=>applyPublicProfileUI())}else{label.textContent='Entrar com Google';if(gIcon){gIcon.style.display='';gIcon.classList.remove('user-photo');gIcon.src=siteTexts.top_account_icon||siteTexts.google_icon||'/assets/google-g.svg';gIcon.alt='Conta'}if(out)out.classList.remove('hidden');if(inn)inn.classList.add('hidden');document.getElementById('sideGeneralChat')?.classList.add('hidden');kanekiPublicProfile=null;profileLoadForUser=''}};
openAccount=function(){updateAccountUI();document.getElementById('myOrdersSection')?.classList.add('hidden');document.getElementById('accountModal')?.classList.remove('hidden');if(currentUser){ensurePublicProfile();loadMyOrders(false)}};
async function switchGoogleAccount(){if(!window.supabaseClient)return;await supabaseClient.auth.signOut();kanekiPublicProfile=null;profileLoadForUser='';const {error}=await supabaseClient.auth.signInWithOAuth({provider:'google',options:{redirectTo:window.location.origin,queryParams:{prompt:'select_account'}}});if(error)alert('Não foi possível trocar de conta: '+error.message)}
logoutAccount=async function(){if(!window.supabaseClient)return;const {error}=await supabaseClient.auth.signOut();if(error)return alert(error.message);kanekiPublicProfile=null;profileLoadForUser='';closeGeneralChat();closeProfileEditor();closeAccount();hidePendingPaymentCTA();document.getElementById('myOrdersQuick')?.classList.add('hidden');document.getElementById('sideGeneralChat')?.classList.add('hidden')};

async function openProfileEditor(){if(!currentUser){openAccount();return}await ensurePublicProfile();applyPublicProfileUI();document.getElementById('profileModal')?.classList.remove('hidden')}
function closeProfileEditor(){document.getElementById('profileModal')?.classList.add('hidden')}
async function uploadProfileAvatar(ev){const file=ev.target.files?.[0];ev.target.value='';if(!file||!currentUser)return;if(!file.type.startsWith('image/'))return alert('Escolha uma imagem.');if(file.size>4*1024*1024)return alert('A foto deve ter no máximo 4 MB.');const ext=(file.name.split('.').pop()||'jpg').replace(/[^a-z0-9]/gi,'').toLowerCase(),path=`profiles/${currentUser.id}/${Date.now()}-${crypto.randomUUID()}.${ext}`;const {error}=await supabaseClient.storage.from('site-media').upload(path,file,{contentType:file.type,upsert:false});if(error)return alert('Não foi possível enviar a foto: '+error.message);const {data}=supabaseClient.storage.from('site-media').getPublicUrl(path),url=data?.publicUrl||'';document.getElementById('profileAvatarUrl').value=url;const prev=document.getElementById('profileAvatarPreview');if(prev){prev.textContent='';prev.style.backgroundImage=`url("${url}")`}}
async function savePublicProfile(){if(!currentUser)return;const display_name=(document.getElementById('profileDisplayName')?.value||'').trim().replace(/\s+/g,' '),avatar_url=(document.getElementById('profileAvatarUrl')?.value||'').trim();if(display_name.length<2)return alert('Escolha um nome com pelo menos 2 caracteres.');if(display_name.length>28)return alert('O nome pode ter no máximo 28 caracteres.');const {data,error}=await supabaseClient.from('profiles').upsert({user_id:currentUser.id,display_name,avatar_url,updated_at:new Date().toISOString()},{onConflict:'user_id'}).select('user_id,display_name,avatar_url,created_at,updated_at').single();if(error)return alert('Não foi possível salvar o perfil: '+error.message);kanekiPublicProfile=data;applyPublicProfileUI();closeProfileEditor();alert('✅ Perfil do chat atualizado.')}

async function getGeneralChatEnabled(){const {data,error}=await supabaseClient.from('site_settings').select('value').eq('key','general_chat_enabled').maybeSingle();if(error){console.warn(error.message);return false}return String(data?.value??'true').toLowerCase()!=='false'}
async function getGeneralChatMuted(){if(!currentUser)return false;const {data,error}=await supabaseClient.rpc('is_general_chat_muted');if(error){console.warn('mute state:',error.message);return false}return !!data}
function setGeneralChatUi(open){generalChatOpenState=!!open;const status=document.getElementById('generalChatStatus'),composer=document.getElementById('generalChatComposer'),closed=document.getElementById('generalChatClosed'),muted=document.getElementById('generalChatMuted');if(status)status.textContent=open?(generalChatMutedState?'● Chat aberto • você está silenciado':'● Chat aberto • somente texto'):'● Chat fechado pelo administrador';closed?.classList.toggle('hidden',open);muted?.classList.toggle('hidden',!open||!generalChatMutedState);composer?.classList.toggle('hidden',!open||generalChatMutedState)}
async function openGeneralChat(){if(!currentUser){openAccount();alert('Entre com Google para acessar o chat geral.');return}closeAccount();await ensurePublicProfile();const modal=document.getElementById('generalChatModal');modal?.classList.remove('hidden');document.body.style.overflow='hidden';generalChatMutedState=await getGeneralChatMuted();setGeneralChatUi(await getGeneralChatEnabled());await loadGeneralChatMessages();subscribeGeneralChat()}
function closeGeneralChat(){document.getElementById('generalChatModal')?.classList.add('hidden');document.body.style.overflow='';if(generalChatPollTimer){clearInterval(generalChatPollTimer);generalChatPollTimer=null}if(generalChatChannel&&window.supabaseClient){supabaseClient.removeChannel(generalChatChannel);generalChatChannel=null}}
async function loadGeneralChatMessages(){const box=document.getElementById('generalChatMessages');if(!box||!currentUser)return;const {data:msgs,error}=await supabaseClient.from('general_chat_messages').select('id,user_id,message,created_at,is_admin').order('created_at',{ascending:false}).limit(120);if(error){box.innerHTML='<div class="general-chat-empty">Chat ainda não foi ativado. Rode o SQL da V12.17.</div>';return}const rows=(msgs||[]).reverse(),ids=[...new Set(rows.map(x=>x.user_id).filter(Boolean))];let profiles={};if(ids.length){const {data}=await supabaseClient.from('profiles').select('user_id,display_name,avatar_url').in('user_id',ids);for(const p of data||[])profiles[p.user_id]=p}if(!rows.length){box.innerHTML='<div class="general-chat-empty">👋 Seja o primeiro a conversar no chat da KANEKI STORE.</div>';return}box.innerHTML=rows.map(m=>generalChatMessageHtml(m,profiles[m.user_id])).join('');box.scrollTop=box.scrollHeight}
function generalChatMessageHtml(m,p){const isAdmin=!!m.is_admin,mine=!isAdmin&&m.user_id===currentUser?.id,name=isAdmin?'KANEKI STORE':(p?.display_name||'Cliente KANEKI'),avatar=isAdmin?(siteTexts.store_avatar||'/assets/logo.svg'):(p?.avatar_url||'');return `<article class="general-msg ${mine?'mine':''} ${isAdmin?'admin-store':''}" data-msg-id="${m.id}">${avatar?`<img class="general-msg-avatar" src="${escapeHtml(avatar)}" alt="">`:`<span class="general-msg-avatar fallback">${escapeHtml(name.charAt(0).toUpperCase())}</span>`}<div class="general-msg-bubble"><b class="general-msg-name">${escapeHtml(name)}${isAdmin?' • Oficial':''}</b><div class="general-msg-text">${escapeHtml(m.message)}</div><small class="general-msg-time">${new Date(m.created_at).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}${mine?' ✓✓':''}</small></div></article>`}
async function sendGeneralChatMessage(){if(!currentUser)return;if(!generalChatOpenState)return alert('O chat geral está fechado no momento.');if(generalChatMutedState)return alert('Você está silenciado no Chat Geral e não pode enviar mensagens agora.');const input=document.getElementById('generalChatInput'),message=(input?.value||'').trim();if(!message)return;if(message.length>500)return alert('Mensagem muito longa. Máximo de 500 caracteres.');await ensurePublicProfile();const {error}=await supabaseClient.from('general_chat_messages').insert({user_id:currentUser.id,message,is_admin:false});if(error){generalChatMutedState=await getGeneralChatMuted();setGeneralChatUi(await getGeneralChatEnabled());return alert(generalChatMutedState?'Você está silenciado no Chat Geral.':error.message)}input.value='';await loadGeneralChatMessages()}
function subscribeGeneralChat(){if(!window.supabaseClient)return;if(generalChatChannel)supabaseClient.removeChannel(generalChatChannel);if(generalChatPollTimer)clearInterval(generalChatPollTimer);generalChatChannel=supabaseClient.channel('kaneki-general-chat-live').on('postgres_changes',{event:'*',schema:'public',table:'general_chat_messages'},()=>loadGeneralChatMessages()).on('postgres_changes',{event:'*',schema:'public',table:'profiles'},()=>loadGeneralChatMessages()).on('postgres_changes',{event:'*',schema:'public',table:'site_settings',filter:'key=eq.general_chat_enabled'},async()=>setGeneralChatUi(await getGeneralChatEnabled())).on('postgres_changes',{event:'*',schema:'public',table:'general_chat_mutes'},async()=>{generalChatMutedState=await getGeneralChatMuted();setGeneralChatUi(await getGeneralChatEnabled())}).subscribe();generalChatPollTimer=setInterval(async()=>{if(document.getElementById('generalChatModal')?.classList.contains('hidden'))return;await loadGeneralChatMessages();generalChatMutedState=await getGeneralChatMuted();setGeneralChatUi(await getGeneralChatEnabled())},1800)}
