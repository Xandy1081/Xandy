function deskEl(id){return document.getElementById(id)}
function deskHtml(id,html){const el=deskEl(id);if(el)el.innerHTML=html;return el}
function deskText(id,text){const el=deskEl(id);if(el)el.textContent=text;return el}
let deskSelected=null,deskFilter='paid',deskMessageChannel=null,deskOrderChannel=null,deskMeta=new Map(),deskTypingTimer=null;
const deskEsc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const readKey=id=>`kaneki_admin_read_${id}`;
function deskStoreAvatar(){return document.getElementById('imgStoreAvatar')?.value?.trim()||'/assets/kaneki-logo-round.png'}
function fulfillmentLabel(o){return {awaiting_payment:'AGUARDANDO PIX',awaiting_service:'AGUARDANDO ATENDIMENTO',in_service:'EM ATENDIMENTO',delivery_sent:'ENTREGA ENVIADA',delivered:'ENTREGUE',cancelled:'CANCELADO'}[o.fulfillment_status]||({paid:'EM ATENDIMENTO',delivered:'ENTREGUE',pending_payment:'AGUARDANDO PIX',cancelled:'CANCELADO'}[o.status]||o.status)}
function deskBeep(){try{const A=window.AudioContext||window.webkitAudioContext,a=new A(),o=a.createOscillator(),g=a.createGain();o.connect(g);g.connect(a.destination);o.frequency.value=680;g.gain.value=.035;o.start();o.stop(a.currentTime+.10)}catch{}}
function removeLegacyTicketPanels(){document.querySelectorAll('#app .panel h2').forEach(h=>{if(h.textContent.trim()==='Pedidos / Tickets'||h.id==='ticketTitle')h.closest('.panel')?.remove()});const g=document.querySelector('#app .grid2');if(g)g.classList.add('v12-admin-grid')}
function deskEnsure(){
 if(document.getElementById('supportDesk'))return;
 removeLegacyTicketPanels();
 const top=document.querySelector('#app .top .actions');if(top){
 const b=document.createElement('button');b.id='kanekiDeskOpen';b.className='btn2';b.innerHTML='💬 CENTRAL DE TICKETS <span id="deskTopUnread" class="desk-top-unread hidden">0</span>';b.onclick=deskOpen;top.prepend(b);
 if(!document.getElementById('kanekiDeliveryAdminOpen')){const d=document.createElement('button');d.id='kanekiDeliveryAdminOpen';d.className='btn2 secondary';d.innerHTML='📦 ENTREGAS';d.onclick=deliveryAdminOpen;top.prepend(d)}
}
 const note=document.createElement('div');note.className='site-remove-note';note.textContent='Banner: deixe qualquer texto vazio e salve para removê-lo. As imagens também podem ser enviadas direto do celular.';document.querySelector('#txtStoreName')?.closest('.settings-grid')?.before(note);
 addSiteUploadButtons();
 const root=document.createElement('div');root.id='supportDesk';root.className='desk hidden';root.innerHTML=`<aside id="deskSide" class="desk-side"><div class="desk-side-head"><h2>💬 Central de tickets</h2><p class="muted">Atenda vários clientes e alterne entre as conversas.</p><div class="desk-tabs"><button class="desk-tab active" data-filter="paid" onclick="deskSetFilter('paid',this)">Atendimento</button><button class="desk-tab" data-filter="delivered" onclick="deskSetFilter('delivered',this)">Entregues</button><button class="desk-tab" data-filter="pending_payment" onclick="deskSetFilter('pending_payment',this)">Aguardando PIX</button><button class="desk-tab" data-filter="all" onclick="deskSetFilter('all',this)">Todos</button></div></div><input id="deskSearch" class="desk-search" placeholder="Buscar Nick, Gmail ou ticket" oninput="deskRenderList()"><div id="deskList" class="desk-list"></div></aside><main class="desk-main"><header class="desk-header"><div class="desk-client"><button class="desk-back btn2 secondary" onclick="deskShowList()">☰</button><img id="deskAvatar" class="desk-avatar" src="/assets/logo.svg"><div class="desk-client-info"><strong id="deskName">Selecione um atendimento</strong><small id="deskEmail">O Nick aparece após o PIX ser confirmado.</small><span id="deskNick" class="desk-nick"></span></div></div><div class="desk-actions"><button id="deskSent" class="btn2 secondary hidden" onclick="deskMarkSent()">📦 ENTREGA ENVIADA</button><button id="deskDelivered" class="btn2 success hidden" onclick="deskMarkDelivered()">✓ CONFIRMAR ENTREGA</button><button id="deskPublishDelivery" class="btn2 secondary hidden" onclick="deskPublishSelected()">📢 PUBLICAR ENTREGA</button><button id="deskCloseTicket" class="btn2 danger hidden" onclick="deskCloseDeliveredTicket()">🗑 FECHAR TICKET</button><button class="desk-close" onclick="deskClose()">✕</button></div></header><div id="deskSystem" class="desk-system">O Mercado Pago libera o ticket automaticamente quando o PIX é aprovado.</div><div class="desk-work"><section id="deskChat" class="desk-chat"><div class="desk-empty"><div><b>KANEKI STORE</b><br>Selecione um ticket para iniciar o atendimento.</div></div></section><aside id="deskOrderInfo" class="desk-order-info"><h3>Detalhes do pedido</h3><div class="desk-info-empty">Selecione um ticket.</div></aside></div><div id="deskTyping" class="desk-typing"></div><footer class="desk-composer"><input id="deskMessage" placeholder="Mensagem para o cliente..." oninput="deskTyping()" onkeydown="if(event.key==='Enter')deskSend()"><label class="desk-camera">📷<input type="file" accept="image/*" onchange="deskUpload(event)" hidden></label><button class="btn2" onclick="deskSend()">Enviar</button></footer></main>`;document.body.appendChild(root);
}
async function deskRefreshMeta(){if(!sb||!orders?.length)return;const ids=orders.map(o=>o.id);const {data}=await sb.from('messages').select('order_id,sender,created_at').in('order_id',ids).order('created_at',{ascending:false}).limit(1000);deskMeta=new Map();for(const m of (data||[])){if(!deskMeta.has(m.order_id))deskMeta.set(m.order_id,{last:m.created_at,lastSender:m.sender});const meta=deskMeta.get(m.order_id);if(m.sender==='customer'){meta.lastCustomer=meta.lastCustomer||m.created_at}}updateUnreadTotal()}
function unreadFor(o){const meta=deskMeta.get(o.id);if(!meta?.lastCustomer)return false;return new Date(meta.lastCustomer).getTime()>Number(localStorage.getItem(readKey(o.id))||0)}
function updateUnreadTotal(){const n=(orders||[]).filter(o=>unreadFor(o)&&o.status==='paid').length;const el=document.getElementById('deskTopUnread');if(el){el.textContent=n;el.classList.toggle('hidden',!n)}}
async function deskOpen(){deskEnsure();const root=deskEl('supportDesk');if(!root)return;root.classList.remove('hidden');document.body.style.overflow='hidden';await deskRefreshMeta();deskRenderList();deskSubscribe()}
function deskClose(){document.getElementById('supportDesk')?.classList.add('hidden');document.body.style.overflow=''}
function deskShowList(){document.getElementById('deskSide')?.classList.remove('desk-mobile-hidden')}
function deskSetFilter(f,btn){deskFilter=f;document.querySelectorAll('.desk-tab').forEach(x=>x.classList.toggle('active',x===btn));deskRenderList()}
function deskMatchesFilter(o){if(o.ticket_closed)return false;if(deskFilter==='all')return true;if(deskFilter==='pending_payment')return o.status==='pending_payment';if(deskFilter==='delivered')return o.status==='delivered';if(deskFilter==='paid')return o.status==='paid';return true}
function deskRenderList(){const listBox=deskEl('deskList');if(!listBox)return;const q=(deskEl('deskSearch')?.value||'').toLowerCase();const list=(orders||[]).filter(o=>deskMatchesFilter(o)&&[o.ticket_code,o.customer_name,o.customer_email,(o.status==='paid'||o.status==='delivered')?o.customer_contact:''].join(' ').toLowerCase().includes(q)).sort((a,b)=>{const ma=deskMeta.get(a.id)?.last||a.last_activity_at||a.created_at,mb=deskMeta.get(b.id)?.last||b.last_activity_at||b.created_at;return new Date(mb)-new Date(ma)});listBox.innerHTML=list.length?list.map(o=>{const unread=unreadFor(o);return `<button class="desk-ticket ${deskSelected?.id===o.id?'active':''}" onclick="deskSelect('${o.id}')"><div class="desk-ticket-top"><b>${deskEsc((o.status==='paid'||o.status==='delivered')?(o.customer_contact||'Cliente'):(o.customer_name||'Cliente'))}</b><span class="badge ${o.status}">${deskEsc(fulfillmentLabel(o))}</span></div><small>${deskEsc(o.ticket_code)} • ${money(o.total)}</small><small>${o.status==='paid'||o.status==='delivered'?'🎮 '+deskEsc(o.customer_contact||'Nick não informado'):'🔒 Nick oculto até confirmar o PIX'}</small>${unread?'<span class="desk-unread">NOVA MENSAGEM</span>':''}</button>`}).join(''):'<p class="muted" style="padding:12px">Nenhum ticket nesta área.</p>'}
function renderOrderInfo(o){const el=document.getElementById('deskOrderInfo');if(!el)return;const items=(o.items||[]).map(i=>`<li>${deskEsc(i.name)} <b>× ${Number(i.qty)||1}</b></li>`).join('');el.innerHTML=`<h3>Detalhes do pedido</h3><div class="desk-info-row"><span>Nick</span><b>${deskEsc(o.customer_contact||'—')}</b></div><div class="desk-info-row"><span>Gmail</span><b>${deskEsc(o.customer_email||'—')}</b></div><div class="desk-info-row"><span>Ticket</span><b>${deskEsc(o.ticket_code)}</b></div><div class="desk-info-row"><span>Total</span><b>${money(o.total)}</b></div><div class="desk-info-row"><span>Pagamento</span><b>${deskEsc(o.payment_status||o.status)}</b></div><div class="desk-info-row"><span>Mercado Pago ID</span><b>${deskEsc(o.mp_payment_id||'—')}</b></div><div class="desk-info-row"><span>Status</span><b>${deskEsc(fulfillmentLabel(o))}</b></div><h4>Produtos</h4><ul>${items||'<li>Sem itens</li>'}</ul>`}
async function deskSelect(id){const o=(orders||[]).find(x=>x.id===id);if(!o)return;if(o.status==='pending_payment'||o.status==='cancelled'){deskSelected=null;deskText('deskName',o.customer_name||'Cliente');deskText('deskEmail','Ticket bloqueado até o pagamento ser aprovado.');deskText('deskNick','');deskHtml('deskChat','<div class="desk-empty">🔒 Atendimento ainda não liberado.</div>');deskEl('deskSent')?.classList.add('hidden');deskEl('deskDelivered')?.classList.add('hidden');renderOrderInfo(o);return}deskSelected=o;localStorage.setItem(readKey(id),String(Date.now()));deskText('deskName',o.customer_contact||'Cliente');deskText('deskEmail',o.customer_email||'');deskText('deskNick','🎮 '+(o.customer_contact||'Não informado'));const av=deskEl('deskAvatar');if(av)av.src=o.customer_avatar_url||'/assets/kaneki-logo-round.png';renderOrderInfo(o);deskUpdateActions();document.getElementById('deskSide')?.classList.add('desk-mobile-hidden');deskRenderList();updateUnreadTotal();await deskLoadMessages();if(deskMessageChannel)sb.removeChannel(deskMessageChannel);deskMessageChannel=sb.channel('desk-'+id).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:'order_id=eq.'+id},p=>{deskAppend(p.new);if(p.new.sender==='customer'){localStorage.setItem(readKey(id),String(Date.now()));deskMessageChannel.send({type:'broadcast',event:'typing',payload:{from:'customer',typing:false}})}}).on('broadcast',{event:'typing'},({payload})=>{const e=document.getElementById('deskTyping');if(e&&payload?.from==='customer')e.textContent=payload.typing?`${deskSelected?.customer_contact||'Cliente'} está digitando...`:''}).subscribe()}
function deskUpdateActions(){if(!deskSelected)return;const f=deskSelected.fulfillment_status||'in_service';document.getElementById('deskSent')?.classList.toggle('hidden',deskSelected.status!=='paid'||f==='delivery_sent');document.getElementById('deskDelivered')?.classList.toggle('hidden',deskSelected.status!=='paid');document.getElementById('deskCloseTicket')?.classList.toggle('hidden',deskSelected.status!=='delivered'||!!deskSelected.ticket_closed);document.getElementById('deskPublishDelivery')?.classList.toggle('hidden',deskSelected.status!=='delivered')}
async function deskLoadMessages(){if(!deskSelected)return;const {data,error}=await sb.from('messages').select('*').eq('order_id',deskSelected.id).order('created_at',{ascending:false}).limit(300);const box=deskEl('deskChat');if(!box)return;box.innerHTML='';if(error){box.innerHTML='<div class="desk-empty">'+deskEsc(error.message)+'</div>';return}for(const m of (data||[]))await deskAppend(m)}
async function deskAppend(m){const box=document.getElementById('deskChat');if(!box||!deskSelected)return;const d=document.createElement('div');d.className='desk-bubble '+m.sender;const isAdmin=m.sender==='admin',avatar=isAdmin?deskStoreAvatar():(deskSelected.customer_avatar_url||''),name=isAdmin?'KANEKI STORE':(deskSelected.customer_contact||'Cliente'),sub=isAdmin?'Atendimento oficial':(deskSelected.customer_email||'Cliente');let media='';if(m.image_path){const {data}=await sb.storage.from('ticket-images').createSignedUrl(m.image_path,3600);if(data?.signedUrl)media=`<a href="${data.signedUrl}" target="_blank"><img class="desk-chat-image" src="${data.signedUrl}" onload="const c=document.getElementById('deskChat');if(c)c.scrollTop=c.scrollHeight"></a>`}d.innerHTML=`<div class="desk-profile">${avatar?`<img src="${deskEsc(avatar)}">`:'<span>👤</span>'}<div><b>${deskEsc(name)}</b><small>${deskEsc(sub)}</small></div></div>${m.message?`<span>${deskEsc(m.message)}</span>`:''}${media}<small class="desk-bubble-time">${new Date(m.created_at).toLocaleString('pt-BR')}</small>`;box.appendChild(d);box.scrollTop=box.scrollHeight}
function deskTyping(){if(!deskMessageChannel)return;deskMessageChannel.send({type:'broadcast',event:'typing',payload:{from:'admin',typing:true}});clearTimeout(deskTypingTimer);deskTypingTimer=setTimeout(()=>deskMessageChannel?.send({type:'broadcast',event:'typing',payload:{from:'admin',typing:false}}),900)}
async function deskSend(){if(!deskSelected)return note('Selecione um ticket pago.',true);const input=deskEl('deskMessage');if(!input)return;const message=input.value.trim();if(!message)return;const {error}=await sb.from('messages').insert({order_id:deskSelected.id,sender:'admin',message});if(error)return note(error.message,true);input.value='';deskMessageChannel?.send({type:'broadcast',event:'typing',payload:{from:'admin',typing:false}})}
async function deskUpload(ev){const file=ev.target.files?.[0];ev.target.value='';if(!file||!deskSelected)return;if(!file.type.startsWith('image/'))return note('Envie somente imagens.',true);if(file.size>8*1024*1024)return note('A imagem deve ter no máximo 8 MB.',true);const {data:{user}}=await sb.auth.getUser();const ext=(file.name.split('.').pop()||'jpg').replace(/[^a-z0-9]/gi,'');const path=`${deskSelected.id}/admin-${user.id}/${Date.now()}-${crypto.randomUUID()}.${ext}`;const {error:upErr}=await sb.storage.from('ticket-images').upload(path,file,{contentType:file.type});if(upErr)return note(upErr.message,true);const {error}=await sb.from('messages').insert({order_id:deskSelected.id,sender:'admin',message:'',image_path:path});if(error)note(error.message,true)}
async function deskMarkSent(){if(!deskSelected||deskSelected.status!=='paid')return;const {error}=await sb.rpc('admin_set_fulfillment',{p_order_id:deskSelected.id,p_status:'delivery_sent'});if(error)return note(error.message,true);await sb.from('messages').insert({order_id:deskSelected.id,sender:'admin',message:'📦 A KANEKI STORE marcou sua entrega como enviada. Confirme os detalhes no chat.'});await loadOrders();deskSelected=(orders||[]).find(x=>x.id===deskSelected.id)||deskSelected;renderOrderInfo(deskSelected);deskUpdateActions();deskRenderList();note('Entrega marcada como enviada.')}
async function deskMarkDelivered(){if(!deskSelected||deskSelected.status!=='paid')return;if(!await kanekiConfirm('Confirmar entrega','Confirmar que este pedido foi entregue ao cliente? Isso libera a avaliação.','success'))return;const {error}=await sb.rpc('admin_set_fulfillment',{p_order_id:deskSelected.id,p_status:'delivered'});if(error)return note(error.message,true);await sb.from('messages').insert({order_id:deskSelected.id,sender:'admin',message:'✅ Entrega confirmada pela KANEKI STORE. Sua avaliação com estrelas e comentário foi liberada.'});await loadOrders();deskSelected=(orders||[]).find(x=>x.id===deskSelected.id)||deskSelected;deskUpdateActions();renderOrderInfo(deskSelected);deskRenderList();note('Entrega confirmada e avaliação liberada.')}

async function deskCloseDeliveredTicket(){
 if(!deskSelected||deskSelected.status!=='delivered'||deskSelected.ticket_closed)return;
 if(!await kanekiConfirm('Fechar ticket','O ticket sairá da Central de Tickets e o cliente não poderá mais responder. O registro do pedido e do pagamento será preservado.','danger'))return;
 const id=deskSelected.id;
 const {error}=await sb.rpc('admin_close_ticket',{p_order_id:id});
 if(error)return note(error.message,true);
 if(deskMessageChannel){await sb.removeChannel(deskMessageChannel);deskMessageChannel=null}
 deskSelected=null;
 document.getElementById('deskName').textContent='Selecione um atendimento';
 document.getElementById('deskEmail').textContent='Ticket fechado com sucesso.';
 document.getElementById('deskNick').textContent='';
 deskHtml('deskChat','<div class="desk-empty">✅ Ticket fechado e removido da Central.</div>');
 deskHtml('deskOrderInfo','<h3>Detalhes do pedido</h3><div class="desk-info-empty">Selecione outro ticket.</div>');
 document.getElementById('deskSent')?.classList.add('hidden');
 document.getElementById('deskDelivered')?.classList.add('hidden');
 document.getElementById('deskCloseTicket')?.classList.add('hidden');
 await loadOrders();await deskRefreshMeta();deskRenderList();
 note('Ticket fechado. O pedido e o pagamento continuam salvos.');
}

function deskSubscribe(){if(deskOrderChannel)sb.removeChannel(deskOrderChannel);deskOrderChannel=sb.channel('desk-orders-live').on('postgres_changes',{event:'*',schema:'public',table:'orders'},async()=>{await loadOrders();await deskRefreshMeta();deskRenderList();if(deskSelected){const fresh=(orders||[]).find(x=>x.id===deskSelected.id);if(fresh){if(fresh.ticket_closed){deskSelected=null;deskHtml('deskChat','<div class="desk-empty">✅ Ticket fechado.</div>');document.getElementById('deskCloseTicket')?.classList.add('hidden')}else{deskSelected=fresh;renderOrderInfo(fresh);deskUpdateActions()}}}}).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages'},async p=>{const o=(orders||[]).find(x=>x.id===p.new.order_id);if(!o)return;const meta=deskMeta.get(o.id)||{};meta.last=p.new.created_at;meta.lastSender=p.new.sender;if(p.new.sender==='customer'){meta.lastCustomer=p.new.created_at;if(deskSelected?.id!==o.id){deskBeep()}}deskMeta.set(o.id,meta);deskRenderList();updateUnreadTotal()}).subscribe()}

async function uploadSiteFile(inputId,file,folder='site'){if(!file)return;if(!file.type.startsWith('image/'))return note('Envie somente imagens.',true);if(file.size>10*1024*1024)return note('Imagem muito grande. Máximo 10 MB.',true);const ext=(file.name.split('.').pop()||'png').replace(/[^a-z0-9]/gi,'');const path=`${folder}/${Date.now()}-${crypto.randomUUID()}.${ext}`;const {error}=await sb.storage.from('site-media').upload(path,file,{contentType:file.type});if(error)return note(error.message,true);const {data}=sb.storage.from('site-media').getPublicUrl(path);const input=document.getElementById(inputId);if(input)input.value=data.publicUrl;note('Imagem enviada. Clique em SALVAR SITE para aplicar.')}
function addSiteUploadButtons(){for(const id of ['imgStoreAvatar','imgBanner','imgGoogle','imgPix','imgTopAccountIcon','imgTopCartIcon','imgSideOrdersIcon','imgSideDiscordIcon','imgSideWhatsappIcon','imgSideChatIcon','imgBenefit1Icon','imgBenefit2Icon','imgBenefit3Icon','imgBenefit4Icon','imgSupportIcon']){const input=document.getElementById(id);if(!input||input.parentElement.querySelector('.site-upload-btn'))continue;const lab=document.createElement('label');lab.className='btn2 secondary site-upload-btn';lab.textContent='📤 ENVIAR IMAGEM';const f=document.createElement('input');f.type='file';f.accept='image/*';f.hidden=true;f.onchange=e=>uploadSiteFile(id,e.target.files?.[0],id);lab.appendChild(f);input.insertAdjacentElement('afterend',lab)}}
function enhanceProductUploads(){document.querySelectorAll('#productsList .product').forEach((el,i)=>{const input=el.querySelector('input[data-k="image"]');if(!input||input.parentElement.querySelector('.product-upload-btn'))return;const lab=document.createElement('label');lab.className='btn2 secondary product-upload-btn';lab.textContent='📤 Enviar imagem';const f=document.createElement('input');f.type='file';f.accept='image/*';f.hidden=true;f.onchange=async e=>{const file=e.target.files?.[0];if(!file)return;const ext=(file.name.split('.').pop()||'png').replace(/[^a-z0-9]/gi,'');const path=`products/${Date.now()}-${crypto.randomUUID()}.${ext}`;const {error}=await sb.storage.from('site-media').upload(path,file,{contentType:file.type});if(error)return note(error.message,true);const {data}=sb.storage.from('site-media').getPublicUrl(path);input.value=data.publicUrl;note('Imagem adicionada. Salve os produtos para aplicar.')};lab.appendChild(f);input.insertAdjacentElement('afterend',lab)})}

window.addEventListener('load',()=>{setTimeout(()=>{deskEnsure();enhanceProductUploads();fetch('/api/cleanup-expired').catch(()=>null)},700);const obs=new MutationObserver(()=>enhanceProductUploads());const p=document.getElementById('productsList');if(p)obs.observe(p,{childList:true,subtree:true})});


/* ===== V12.10 - CENTRAL DE ENTREGAS DO ADM ===== */
let deliveryAdminImageUrl='';
function deliveryAdminEnsure(){
 if(document.getElementById('deliveryAdmin'))return;
 const root=document.createElement('div');
 root.id='deliveryAdmin';root.className='delivery-admin hidden';
 root.innerHTML=`<div class="delivery-admin-card">
   <header class="delivery-admin-head">
     <div><small>KANEKI STORE</small><h2>📦 Central de Entregas</h2><p>Publique pedidos entregues no canal público do site.</p></div>
     <button class="desk-close" onclick="deliveryAdminClose()">✕</button>
   </header>
   <div class="delivery-admin-form">
     <div class="field"><label>Mensagem padrão da publicação</label><input id="deliveryAdminMessage" value="Entrega concluída com sucesso. Obrigado pela confiança!"></div>
     <div class="field"><label>Imagem opcional</label><div class="actions"><input id="deliveryAdminImage" placeholder="URL da imagem (opcional)"><label class="btn2 secondary">📤 Enviar imagem<input type="file" accept="image/*" hidden onchange="deliveryAdminUpload(event)"></label></div></div>
   </div>
   <div class="delivery-admin-grid">
     <section><h3>Pedidos entregues</h3><div id="deliveryReadyList" class="delivery-admin-list"></div></section>
     <section><h3>Publicações no site</h3><div id="deliveryPublishedList" class="delivery-admin-list"></div></section>
   </div>
 </div>`;
 document.body.appendChild(root);
}
async function deliveryAdminOpen(){
 deliveryAdminEnsure();
 document.getElementById('deliveryAdmin')?.classList.remove('hidden');
 document.body.style.overflow='hidden';
 if(typeof loadOrders==='function')await loadOrders();
 await deliveryAdminLoad();
}
function deliveryAdminClose(){document.getElementById('deliveryAdmin')?.classList.add('hidden');document.body.style.overflow=''}
async function deliveryAdminUpload(ev){
 const file=ev.target.files?.[0];ev.target.value='';if(!file)return;
 if(!file.type.startsWith('image/'))return note('Envie somente imagens.',true);
 const ext=(file.name.split('.').pop()||'jpg').replace(/[^a-z0-9]/gi,'');
 const path=`deliveries/${Date.now()}-${crypto.randomUUID()}.${ext}`;
 const {error}=await sb.storage.from('site-media').upload(path,file,{contentType:file.type});
 if(error)return note(error.message,true);
 const {data}=sb.storage.from('site-media').getPublicUrl(path);
 deliveryAdminImageUrl=data.publicUrl;
 const inp=document.getElementById('deliveryAdminImage');if(inp)inp.value=deliveryAdminImageUrl;
 note('Imagem pronta para a publicação.');
}
function deliveryItemsText(o){return (o.items||[]).map(i=>`${i.name} × ${Number(i.qty)||1}`).join(' • ')}
async function deliveryAdminLoad(){
 const ready=document.getElementById('deliveryReadyList'),pub=document.getElementById('deliveryPublishedList');if(!ready||!pub)return;
 const {data:posts,error}=await sb.from('deliveries').select('*').order('created_at',{ascending:false});
 if(error){ready.innerHTML=`<p class="muted">${deskEsc(error.message)}</p>`;pub.innerHTML='<p class="muted">Rode o SQL da V12.10 para ativar esta área.</p>';return}
 const activePosts=(posts||[]).filter(p=>p.active===true);
 // Um pedido que já virou publicação não deve voltar para a fila depois de removido.
 // As publicações inativas continuam registradas como descartadas no banco.
 const processedOrderIds=new Set((posts||[]).filter(p=>p.order_id).map(p=>String(p.order_id)));
 const delivered=(orders||[]).filter(o=>o.status==='delivered').sort((a,b)=>new Date(b.delivered_at||b.created_at)-new Date(a.delivered_at||a.created_at));
 const waiting=delivered.filter(o=>!processedOrderIds.has(String(o.id)));
 ready.innerHTML=waiting.length?waiting.map(o=>`<article class="delivery-admin-item"><div><b>${deskEsc(o.customer_contact||o.customer_name||'Cliente')}</b><small>${deskEsc(o.ticket_code)} • ${deskEsc(deliveryItemsText(o)||'Pedido')}</small></div><button class="btn2 success" onclick="deliveryAdminPublish('${o.id}')">PUBLICAR</button></article>`).join(''):'<p class="muted">Nenhum pedido aguardando publicação.</p>';
 pub.innerHTML=activePosts.length?activePosts.map(p=>`<article class="delivery-admin-item"><div><b>${deskEsc(p.customer_name||'Cliente')}</b><small>${deskEsc(p.items_text||'Entrega')} • ${new Date(p.created_at).toLocaleString('pt-BR')}</small></div><button class="btn2 danger" onclick="deliveryAdminRemove(${p.id})">REMOVER</button></article>`).join(''):'<p class="muted">Nenhuma publicação.</p>';
}
async function deliveryAdminPublish(orderId){
 const o=(orders||[]).find(x=>x.id===orderId);if(!o||o.status!=='delivered')return note('Somente pedidos entregues podem ser publicados.',true);
 const message=document.getElementById('deliveryAdminMessage')?.value.trim()||'Entrega concluída com sucesso.';
 const image=document.getElementById('deliveryAdminImage')?.value.trim()||deliveryAdminImageUrl||'';
 const payload={order_id:o.id,customer_name:o.customer_contact||o.customer_name||'Cliente',items_text:deliveryItemsText(o),message,image_url:image,active:true,updated_at:new Date().toISOString()};
 const {error}=await sb.from('deliveries').upsert(payload,{onConflict:'order_id'});
 if(error)return note(error.message,true);
 note('✅ Entrega publicada no site.');
 await deliveryAdminLoad();
}
async function deskPublishSelected(){if(!deskSelected)return;await deliveryAdminPublish(deskSelected.id)}
async function deliveryAdminRemove(id){
 const {error}=await sb.from('deliveries').delete().eq('id',id);
 if(error)return note(error.message,true);
 document.querySelector(`#deliveryPublishedList .delivery-admin-item button[onclick="deliveryAdminRemove(${id})"]`)?.closest('.delivery-admin-item')?.remove();
 note('Publicação removida do site e da lista.');
 await deliveryAdminLoad();
}


/* V12.15 — confirmações visuais KANEKI */
function kanekiConfirm(title,message,tone='danger'){
  return new Promise(resolve=>{
    document.getElementById('kanekiAdminConfirm')?.remove();
    const icon=tone==='success'?'✓':tone==='warning'?'★':'!';
    const el=document.createElement('div');
    el.id='kanekiAdminConfirm'; el.className='rz-confirm-overlay';
    el.innerHTML=`<div class="rz-confirm-card ${tone}"><div class="rz-confirm-icon">${icon}</div><div><small>KANEKI STORE • PAINEL ADM</small><h3>${title}</h3><p>${message}</p></div><div class="rz-confirm-actions"><button class="btn2 secondary" data-no>Cancelar</button><button class="btn2" data-yes>Confirmar</button></div></div>`;
    document.body.appendChild(el);
    const done=v=>{el.remove();resolve(v)};
    el.querySelector('[data-no]').onclick=()=>done(false);
    el.querySelector('[data-yes]').onclick=()=>done(true);
    el.onclick=e=>{if(e.target===el)done(false)};
  });
}

/* ===== V12.17 - MODERACAO DO CHAT GERAL ===== */
let adminGeneralChatChannel=null;
async function adminGetGeneralChatState(){
 const {data,error}=await sb.from('site_settings').select('value').eq('key','general_chat_enabled').maybeSingle();
 if(error)return true;return String(data?.value??'true').toLowerCase()!=='false';
}
async function adminSetGeneralChat(enabled){
 const {error}=await sb.from('site_settings').upsert({key:'general_chat_enabled',value:enabled?'true':'false',updated_at:new Date().toISOString()},{onConflict:'key'});
 if(error)return note('Não foi possível alterar o chat: '+error.message,true);
 await adminRefreshGeneralChatState();note(enabled?'Chat geral aberto para os clientes.':'Chat geral fechado. As mensagens foram preservadas.');
}
async function adminRefreshGeneralChatState(){
 const enabled=await adminGetGeneralChatState(),badge=document.getElementById('adminChatStateBadge');
 if(badge){badge.textContent=enabled?'ABERTO':'FECHADO';badge.style.background=enabled?'#174e35':'#63232a'}
 document.getElementById('adminChatOpenBtn')?.toggleAttribute('disabled',enabled);
 document.getElementById('adminChatCloseBtn')?.toggleAttribute('disabled',!enabled);
}
async function adminLoadGeneralChat(){
 const box=document.getElementById('adminGeneralChatList');if(!box)return;
 await adminRefreshGeneralChatState();
 const {data:msgs,error}=await sb.from('general_chat_messages').select('id,user_id,message,created_at,is_admin').order('created_at',{ascending:false}).limit(200);
 if(error){box.innerHTML='<p class="muted">Rode o SQL da V12.17 para ativar o Chat Geral.</p>';return}
 const ids=[...new Set((msgs||[]).filter(m=>!m.is_admin).map(m=>m.user_id).filter(Boolean))],profiles={},muted=new Set();
 if(ids.length){const {data}=await sb.from('profiles').select('user_id,display_name,avatar_url').in('user_id',ids);for(const p of data||[])profiles[p.user_id]=p;const {data:mutes}=await sb.from('general_chat_mutes').select('user_id').in('user_id',ids);for(const m of mutes||[])muted.add(m.user_id)}
 box.innerHTML=(msgs||[]).length?(msgs||[]).map(m=>{const isAdmin=!!m.is_admin,p=profiles[m.user_id]||{},name=isAdmin?'KANEKI STORE':(p.display_name||'Cliente KANEKI'),avatar=isAdmin?'/assets/logo.svg':(p.avatar_url||''),isMuted=muted.has(m.user_id);return `<article class="admin-chat-msg ${isAdmin?'admin-chat-official':''}">${avatar?`<img class="admin-chat-avatar" src="${deskEsc(avatar)}">`:`<span class="admin-chat-avatar admin-chat-avatar-fallback">${deskEsc(name.charAt(0).toUpperCase())}</span>`}<div><b>${deskEsc(name)}${isAdmin?' • OFICIAL':''}</b><p>${deskEsc(m.message)}</p><small>${new Date(m.created_at).toLocaleString('pt-BR')}</small></div><div class="admin-chat-actions">${!isAdmin?`<button class="${isMuted?'admin-chat-unmute':'admin-chat-mute'}" onclick="adminSetGeneralChatMute('${deskEsc(m.user_id)}',${isMuted?'false':'true'})">${isMuted?'🔊 DESMUTAR':'🔇 MUTAR'}</button>`:''}<button class="admin-chat-delete" onclick="adminDeleteGeneralMessage(${Number(m.id)})">EXCLUIR</button></div></article>`}).join(''):'<p class="muted" style="padding:14px">Nenhuma mensagem no chat geral.</p>';
}

async function adminSendGeneralChat(){
 const input=document.getElementById('adminGeneralChatInput'),message=(input?.value||'').trim();if(!message)return;if(message.length>500)return note('Mensagem muito longa.',true);
 const {error}=await sb.rpc('admin_send_general_chat',{p_message:message});if(error)return note(error.message,true);input.value='';await adminLoadGeneralChat();
}
async function adminSetGeneralChatMute(userId,muted){
 const title=muted?'Silenciar cliente':'Remover silêncio',text=muted?'Este cliente não poderá enviar novas mensagens no Chat Geral, mas continuará podendo ler.':'Este cliente poderá voltar a enviar mensagens no Chat Geral.';
 if(!await kanekiConfirm(title,text,muted?'danger':'success'))return;
 const {error}=await sb.rpc('admin_set_general_chat_mute',{p_user_id:userId,p_muted:muted});if(error)return note(error.message,true);await adminLoadGeneralChat();note(muted?'Cliente silenciado.':'Cliente liberado para conversar.');
}

async function adminDeleteGeneralMessage(id){
 if(!await kanekiConfirm('Excluir mensagem','Esta mensagem será removida do chat geral para todos.','danger'))return;
 const {error}=await sb.from('general_chat_messages').delete().eq('id',id);if(error)return note(error.message,true);await adminLoadGeneralChat();note('Mensagem excluída.');
}
async function adminClearGeneralChat(){
 if(!await kanekiConfirm('Limpar chat geral','Todas as mensagens do chat geral serão apagadas. Os perfis dos clientes serão preservados.','danger'))return;
 const {error}=await sb.from('general_chat_messages').delete().not('id','is',null);if(error)return note(error.message,true);await adminLoadGeneralChat();note('Chat geral limpo.');
}
function adminSubscribeGeneralChat(){
 if(adminGeneralChatChannel)sb.removeChannel(adminGeneralChatChannel);
 adminGeneralChatChannel=sb.channel('admin-general-chat-live').on('postgres_changes',{event:'*',schema:'public',table:'general_chat_messages'},()=>adminLoadGeneralChat()).on('postgres_changes',{event:'*',schema:'public',table:'site_settings',filter:'key=eq.general_chat_enabled'},()=>adminRefreshGeneralChatState()).on('postgres_changes',{event:'*',schema:'public',table:'general_chat_mutes'},()=>adminLoadGeneralChat()).subscribe();
}
window.addEventListener('load',()=>setTimeout(()=>{adminLoadGeneralChat();adminSubscribeGeneralChat();const supportIcon=document.getElementById('imgSupportIcon');if(supportIcon){if(!supportIcon.value.trim())supportIcon.value='/assets/whatsapp.svg';const label=supportIcon.closest('.field')?.querySelector('label');if(label)label.textContent='PNG / ícone do botão WhatsApp'}},1200));
