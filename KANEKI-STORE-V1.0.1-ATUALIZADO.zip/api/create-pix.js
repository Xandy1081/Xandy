const MP_URL='https://api.mercadopago.com/v1/payments';
const json=(res,body,status=200)=>{res.statusCode=status;res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify(body));};
async function sbFetch(path,opts={}){const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!url||!key)throw new Error('Supabase não configurado.');const r=await fetch(`${url}/rest/v1/${path}`,{...opts,headers:{apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json',...(opts.headers||{})}});const t=await r.text();let d=null;try{d=JSON.parse(t)}catch{}if(!r.ok)throw new Error(d?.message||t||`Supabase ${r.status}`);return d}
async function rpc(name,body){return sbFetch(`rpc/${name}`,{method:'POST',body:JSON.stringify(body)})}
async function authenticatedUser(req){const token=String(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!token)return null;const r=await fetch(`${process.env.SUPABASE_URL}/auth/v1/user`,{headers:{apikey:process.env.SUPABASE_ANON_KEY||'',Authorization:`Bearer ${token}`}});return r.ok?r.json():null}
export default async function handler(req,res){
 if(req.method!=='POST')return json(res,{error:'Método não permitido.'},405);
 let reserved=false,orderId='';
 try{
  const user=await authenticatedUser(req);if(!user?.id)return json(res,{error:'Faça login novamente.'},401);
  const {order_id}=req.body||{};orderId=String(order_id||'');if(!/^[0-9a-f-]{36}$/i.test(orderId))return json(res,{error:'Pedido inválido.'},400);
  const token=process.env.MERCADOPAGO_ACCESS_TOKEN;if(!token)throw new Error('Mercado Pago ainda não configurado na Vercel.');
  const order=(await sbFetch(`orders?id=eq.${encodeURIComponent(orderId)}&customer_user_id=eq.${encodeURIComponent(user.id)}&select=*`))[0];
  if(!order)return json(res,{error:'Pedido não encontrado.'},404);
  if(order.status!=='pending_payment')return json(res,{error:'Pedido não está aguardando pagamento.'},409);
  if(order.mp_payment_id)return json(res,{ok:true,payment_id:order.mp_payment_id,qr_code:order.pix_qr_code,qr_code_base64:order.pix_qr_base64,status:order.payment_status,expires_at:order.expires_at,total:order.total});
  const canonical=await rpc('prepare_order_for_payment',{p_order_id:order.id,p_user_id:user.id});reserved=true;
  const total=Number(canonical.total),expiresAt=canonical.expires_at;
  const base=(process.env.PUBLIC_SITE_URL||'').replace(/\/$/,'');if(!/^https:\/\//.test(base))throw new Error('Configure PUBLIC_SITE_URL com HTTPS.');
  const body={transaction_amount:total,description:`KANEKI STORE - ${order.ticket_code}`,payment_method_id:'pix',external_reference:order.id,notification_url:`${base}/api/mercadopago-webhook`,date_of_expiration:expiresAt,payer:{email:order.customer_email}};
  const r=await fetch(MP_URL,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json','X-Idempotency-Key':`kaneki-${order.id}`},body:JSON.stringify(body)});const p=await r.json();if(!r.ok)throw new Error(p.message||'Mercado Pago recusou o PIX.');
  const td=p.point_of_interaction?.transaction_data||{};
  await sbFetch(`orders?id=eq.${encodeURIComponent(order.id)}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({mp_payment_id:String(p.id),pix_qr_code:td.qr_code||'',pix_qr_base64:td.qr_code_base64||'',payment_status:p.status||'pending',payment_updated_at:new Date().toISOString()})});
  return json(res,{ok:true,payment_id:p.id,status:p.status,qr_code:td.qr_code||'',qr_code_base64:td.qr_code_base64||'',expires_at:expiresAt,total});
 }catch(e){console.error(e);if(reserved&&orderId)await rpc('release_order_stock',{p_order_id:orderId,p_reason:'pix_creation_failed'}).catch(()=>null);return json(res,{error:e.message||'Erro interno.'},500)}
}
